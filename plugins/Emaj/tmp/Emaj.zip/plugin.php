﻿<?php
require_once('./classes/Plugin.php');
include_once('./plugins/Emaj/classes/EmajDb.php');

class Emaj extends Plugin {

	/**
	 * Attributes
	 */
	protected $name = 'Emaj';
	protected $lang;
	protected $conf = array();
	protected $emajdb = null;
	protected $oldest_supported_emaj_version = '0.11.0';		// Oldest emaj version supported by the plugin = 0.11.0
	protected $oldest_supported_emaj_version_num = 1100;

	/**
	 * Constructor
	 * Call parent constructor, passing the language that will be used.
	 * @param $language Current phpPgAdmin language. If it was not found in the plugin, English will be used.
	 */
	function __construct($language) {

		/* loads $this->lang and $this->conf */
		parent::__construct($language);

		// instanciate early an EmajDb class
		$this->emajdb = new EmajDb();
	}

	/**
	 * This method returns the functions to hook in the phpPgAdmin core.
	 * To do include a function just put in the $hooks array the follwing code:
	 *   '<hook_name>' => array('function1', 'function2').
	 *
	 * Example:
	 * $hooks = array(
	 *     'toplinks' => array('add_plugin_toplinks'),
	 *     'tabs' => array('add_tab_entry'),
	 *     'action_buttons' => array('add_more_an_entry')
	 * );
	 *
	 * @return $hooks
	 */
	function get_hooks() {
		$hooks = array(
			'tabs' => array('add_plugin_tabs')
		);
		return $hooks;
	}

	/**
	 * Insertion of the E-Maj tab in the database section
	 */
	function add_plugin_tabs(&$plugin_functions_parameters) {

		$tabs = &$plugin_functions_parameters['tabs'];

		switch ($plugin_functions_parameters['section']) {
			case 'database':
				$tabs['emaj'] = array (
					'title' => 'E-Maj',
					'url' => 'plugin.php',
					'urlvars' => array(
						'subject' => 'database',
						'action' => 'list_groups',
						'plugin' => $this->name
					),
					'hide' => !($this->emajdb->isEnabled()&&$this->emajdb->isAccessible()),
					'icon' => $this->icon('Emaj')
				);
				break;
			  break;
			case 'emaj':
				$tabs['emajgroups'] = array (
					'title' => $this->lang['emajgroups'],
					'url' => 'plugin.php',
					'urlvars' => array(
						'subject' => 'emaj',
						'action' => 'list_groups',
						'plugin' => $this->name
					),
					'icon' => $this->icon('EmajGroup')
				);
				$tabs['emajdefinegroups'] = array (
					'title' => $this->lang['emajdefinegroups'],
					'url' => 'plugin.php',
					'urlvars' => array(
						'subject' => 'emaj',
						'action' => 'define_groups',
						'plugin' => $this->name
					),
					'icon' => 'Subscriptions'
				);
				$tabs['emajmonitorrlbk'] = array (
					'title' => $this->lang['emajmonitorrlbk'],
					'url' => 'plugin.php',
					'urlvars' => array(
						'subject' => 'emaj',
						'action' => 'rlbk_activity',
						'plugin' => $this->name
					),
					'hide' => ($this->emajdb->getNumEmajVersion() < 10100),
					'icon' => $this->icon('EmajRollback')
				);
				$tabs['emajcheck'] = array (
					'title' => $this->lang['emajcheck'],
					'url' => 'plugin.php',
					'urlvars' => array(
						'subject' => 'emaj',
						'action' => 'check',
						'plugin' => $this->name
					),
					'icon' => 'CheckConstraint'
				);
				break;
		}
	}

	/**
	 * This method returns the functions that will be used as actions.
	 * To do include a function that will be used as action, just put in the $actions array the following code:
	 *
	 * $actions = array(
	 *	'show_page',
	 *	'show_error',
	 * );
	 *
	 * @return $actions
	 */
	function get_actions() {
		$actions = array(
		'alter_group',
		'alter_group_ok',
		'assign_tblseq',
		'assign_tblseq_ok',
		'call_sqledit',
		'check',
		'comment_group',
		'comment_group_ok',
		'comment_mark_group',
		'comment_mark_group_ok',
		'content_group',
		'create_group',
		'create_group_ok',
		'define_groups',
		'delete_before_mark',
		'delete_before_mark_ok',
		'delete_mark',
		'delete_mark_ok',
		'detail_group',
		'drop_group',
		'drop_group_ok',
		'filterrlbk',
		'list_groups',
		'log_stat_group',
		'remove_tblseq',
		'remove_tblseq_ok',
		'rename_mark_group',
		'rename_mark_group_ok',
		'set_mark_group',
		'set_mark_group_ok',
		'set_mark_groups',
		'set_mark_groups_ok',
		'sim_rlbk_mark',
		'reset_group',
		'reset_group_ok',
		'rlbk_activity',
		'rollback_group',
		'rollback_group_ok',
		'rollback_groups',
		'rollback_groups_ok',
		'start_group',
		'start_group_ok',
		'start_groups',
		'start_groups_ok',
		'stop_group',
		'stop_group_ok',
		'stop_groups',
		'stop_groups_ok',
		'tree',
		);
		return $actions;
	}

	/**
	 * callback functions to define authorized actions on lists
	 */

	// Functions to dynamicaly modify actions list for each table group to display
	function loggingGroupPre(&$rowdata, $loggingActions) {
		global $emajdb;
		// disable the rollback button for audit_only groups
		if (!$this->emajdb->isGroupRollbackable($rowdata->fields['group_name'])){
			$loggingActions['rollback_group']['disable'] = true;
		}
		return $loggingActions;
	}

		// Function to dynamicaly modify actions list for the group
	function groupPre(&$rowdata, $groupActions) {
		global $emajdb;
		// disable admin functions for viewer role
//		if (!$this->emajdb->isEmaj_Adm()){
//			$groupActions['startgroup']['disable'] = true;
//			$groupActions['resetgroup']['disable'] = true;
//			$groupActions['dropgroup']['disable'] = true;
//			$groupActions['stopgroup']['disable'] = true;
//			$groupActions['setmarkgroup']['disable'] = true;
//			$groupActions['commentgroup']['disable'] = true;
//		}
		// disable functions for IDLE group
		if ($rowdata->fields['group_state'] != 'LOGGING'){
			$groupActions['stopgroup']['disable'] = true;
			$groupActions['setmarkgroup']['disable'] = true;
		};
		// disable functions for LOGGING group
		if ($rowdata->fields['group_state'] != 'IDLE'){
			$groupActions['startgroup']['disable'] = true;
			$groupActions['resetgroup']['disable'] = true;
			$groupActions['dropgroup']['disable'] = true;
			$groupActions['altergroup']['disable'] = true;
		};
		return $groupActions;
	}

		// Function to dynamicaly modify actions list for each mark
	function markPre(&$rowdata, $actions) {
		global $emajdb, $previous_cumlogrows;

		if ($rowdata->fields['mark_state'] != 'ACTIVE'){
			$actions['statrlbkmark']['disable'] = true;
		}
		if ($rowdata->fields['mark_state'] != 'ACTIVE' || !$this->emajdb->isEmaj_Adm()){
			$actions['rollbackgroup']['disable'] = true;
		}
		if (!$this->emajdb->isEmaj_Adm()){
			$actions['renamemark']['disable'] = true;
			$actions['deletemark']['disable'] = true;
			$actions['deletebeforemark']['disable'] = true;
			$actions['commentmark']['disable'] = true;
		}
		if ($this->emajdb->isGroupRollbackable($rowdata->fields['mark_group'])==0){
			$actions['statrlbkmark']['disable'] = true;
			$actions['rollbackgroup']['disable'] = true;
		}
		// compute the cumulative number of log rows
		// (this is not done in SQL because windowing functions are not available with pg version 8.3-)
		$rowdata->fields['mark_cumlogrows'] = $previous_cumlogrows + $rowdata->fields['mark_logrows'];
		$previous_cumlogrows = $rowdata->fields['mark_cumlogrows'];
		return $actions;
	}

	/**
	 * Render callback functions
	 */

	function renderGroupType($val) {
		return $val == 'ROLLBACKABLE' ? $this->lang['emajrollbackable'] : $this->lang['emajauditonly'];
	}

	function renderGroupState($val) {
		return $val == 'IDLE' ? $this->lang['emajidle'] : $this->lang['emajlogging'];
	}

	function renderTblSeq($val) {
		global $misc;
		if ($val == '!'){						// unknown type
			return "<img src=\"".$misc->icon('ObjectNotFound')."\" alt=\"{$this->lang['emajunknownobject']}\" title=\"{$this->lang['emajunknownobject']}\" style=\"vertical-align:bottom;\" />";
		}
		return $val == 'r' ? $lang['strtable'] : $lang['strsequence'];
	}

	function renderMarkState($val) {
		global $lang;
		return $val == 'ACTIVE' ? $lang['emajactive'] : $lang['emajdeleted'];
	}

	function renderDiagnostic($val) {
		global $misc;
		if (preg_match("/[Nn]o error /",$val)){
			$icon = 'CheckConstraint';
		}else{
			$icon = 'CorruptedDatabase';
		}
		return "<img src=\"".$misc->icon($icon)."\" style=\"vertical-align:bottom;\" />" . $val;
	}

	// Function to dynamicaly modify actions list for tables
	function tablePre(&$rowdata, $actions) {
		// disable 'add' if the table already belong to a group
		// otherwise, disable 'suppress'
		if ($rowdata->fields['grpdef_group'] != NULL){
			$actions['assign']['disable'] = true;
		}else{
			$actions['remove']['disable'] = true;
		};
		return $actions;
	}

	// Function to dynamicaly modify the schema owner columns content
	// It generates a warning icon when the owner is not known (i.e. the object does not exist)
	function renderSchemaOwner($val) {
		global $misc, $lang;
		if ($val == '!'){
			return "<img src=\"".$misc->icon('ObjectNotFound')."\" alt=\"{$this->lang['emajunknownobject']}\" title=\"{$this->lang['emajunknownobject']}\" style=\"vertical-align:bottom;\" />";
		}
		return $val;
	}

	/**
	 * Show list of emaj groups created
	 */
	function list_groups($msg = '', $errMsg = '') {
		global $lang, $misc;

		$this->printPageHeader('emaj','emajgroups');

		$emajOK = $this->printEmajHeader("action=list_groups",$this->lang['emajgrouplist']);

		if ($emajOK){
			$this->printMsg($msg,$errMsg);

			$idleGroups = $this->emajdb->getIdleGroups();
			$loggingGroups = $this->emajdb->getLoggingGroups();

			$columns = array(
				'group' => array(
					'title' => $this->lang['emajgroup'],
					'field' => field('group_name'),
					'url'   => "plugin.php?plugin={$this->name}&amp;action=detail_group&amp;{$misc->href}&amp;",
					'vars'  => array('group' => 'group_name'),
				),
				'creationdatetime' => array(
					'title' => $this->lang['emajcreationdatetime'],
					'field' => field('creation_datetime'),
					'params'=> array('align' => 'center'),
				),
				'nbtbl' => array(
					'title' => $this->lang['emajnbtbl'],
					'field' => field('group_nb_table'),
					'type'  => 'numeric'
				),
				'nbseq' => array(
					'title' => $this->lang['emajnbseq'],
					'field' => field('group_nb_sequence'),
					'type'  => 'numeric'
				),
				'rollbackable' => array(
					'title' => $lang['strtype'],
					'field' => field('group_type'),
//					'type'	=> 'callback',
					'params'=> array(
							'function' => array($this, 'renderGroupType'),
							'align' => 'center'
							)
				),
				'nbmark' => array(
					'title' => $this->lang['emajnbmark'],
					'field' => field('nb_mark'),
					'type'  => 'numeric'
				),
				'actions' => array(
					'title' => $lang['stractions'],
				),
				'comment' => array(
					'title' => $lang['strcomment'],
					'field' => field('abbr_comment'),
				),
			);

			$urlvars = $misc->getRequestVars();

			$loggingActions = array(
				'multiactions' => array(
					'keycols' => array('group' => 'group_name'),
					'url' => "plugin.php?plugin={$this->name}&amp;back=list",
					'default' => 'set_mark_group',
				),
				'detail_group' => array(
					'content' => $this->lang['emajdetail'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'detail_group',
								'back' => 'list',
								'group' => field('group_name'),
							)))),
				),
				'content' => array(
					'content' => $this->lang['emajcontent'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'content_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
			);
			if ($this->emajdb->isEmaj_Adm()){
				$loggingActions = array_merge($loggingActions, array(
				'stop_group' => array(
					'content' => $lang['strstop'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'stop_group',
								'back' => 'list',
								'group' => field('group_name'),
							)))),
					'multiaction' => 'stop_groups',
				),
				'set_mark_group' => array(
					'content' => $this->lang['emajsetmark'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'set_mark_group',
								'back' => 'list',
								'group' => field('group_name'),
							)))),
					'multiaction' => 'set_mark_groups',
				),
				'rollback_group' => array(
					'content' => $this->lang['emajrlbk'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'rollback_group',
								'back' => 'list',
								'group' => field('group_name'),
							)))),
					'multiaction' => 'rollback_groups',
				),
				'comment_group' => array(
					'content' => $this->lang['emajsetcomment'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'comment_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
				));
			};

			$idleActions = array(
			'multiactions' => array(
				'keycols' => array('group' => 'group_name'),
				'url' => "plugin.php?plugin={$this->name}&amp;back=list",
				'default' => 'start_group',
				),
				'detail_group' => array(
					'content' => $this->lang['emajdetail'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'detail_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
				'content' => array(
					'content' => $this->lang['emajcontent'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'content_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
			);
			if ($this->emajdb->isEmaj_Adm()){
				$idleActions = array_merge($idleActions, array(
				'start_group' => array(
					'content' => $lang['strstart'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'start_group',
								'back' => 'list',
								'group' => field('group_name'),
							)))),
					'multiaction' => 'start_groups',
				),
				'reset_group' => array(
					'content' => $lang['strreset'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'reset_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
				'drop_group' => array(
					'content' => $lang['strdrop'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'drop_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
				));
			};
			if ($this->emajdb->isEmaj_Adm() && $this->emajdb->getNumEmajVersion() >= 10000){	// version >= 1.0.0
				$idleActions = array_merge($idleActions, array(
					'alter_group' => array(
						'content' => $lang['stralter'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'alter_group',
									'back' => 'list',
									'group' => field('group_name'),
							))))
					),
				));
			};
			if ($this->emajdb->isEmaj_Adm()){
				$idleActions = array_merge($idleActions, array(
				'comment_group' => array(
					'content' => $this->lang['emajsetcomment'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'comment_group',
								'back' => 'list',
								'group' => field('group_name'),
							))))
				),
			));
			};

			echo "<h3>{$this->lang['emajlogginggroups']}:</h3>\n";
			$misc->printTable($loggingGroups, $columns, $loggingActions, 'loggingGroups', $this->lang['emajnologginggroup']
//				, array($this, 'loggingGroupPre')
			);
			echo "<hr>";
			echo "<h3>{$this->lang['emajidlegroups']}:</h3>\n";
			$misc->printTable($idleGroups, $columns, $idleActions, 'idleGroups', $this->lang['emajnoidlegroup']);
			echo "<hr>";

			// get groups name known in emaj_group_def table but not yet created (i.e. not known in emaj_group table)
			// for emaj_adm role only
			if ($this->emajdb->isEmaj_Adm()){
				$newGroups = $this->emajdb->getNewGroups();
				if ($newGroups->recordCount() > 0) {

				// form used to create a new group

					echo "<form id=\"createGroup_form\" action=\"plugin.php?plugin={$this->name}&amp;action=create_group&amp;back=list&amp;{$misc->href}\"";
					echo "  method=\"post\" enctype=\"multipart/form-data\">\n";
					echo "<table>\n";
					echo "<tr>\n";
					echo "<th class=\"data\" style=\"text-align: left\" colspan=\"2\">{$this->lang['emajcreategroup']}</th>\n";
					echo "</tr>\n";
					echo "<tr>\n";
					echo "<td class=\"data1\">\n";
					echo "\t<select name=\"group\">\n";
					foreach($newGroups as $r)
						echo "\t\t<option value=\"",htmlspecialchars($r['group_name']),"\">",htmlspecialchars($r['group_name']),"</option>\n";
					echo "\t</select>\n";
					echo "<input type=\"submit\" value=\"{$lang['strcreate']}\" />\n";
					echo "</td>\n";
					echo "</tr>\n";
					echo "</table>\n";
					echo '</form>';
				}
			}
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Displays all detailed information about one group
	 */
	function detail_group($msg = '', $errMsg = '') {
		global $misc, $lang;

		// insert javascript for automatic refresh of marks list
//		$refreshTime = 10000;				// refresh time = 10 seconds (not linked to $conf['ajax_refresh'] parameter)
//		echo "<script src=\"js/emaj.js\" type=\"text/javascript\"></script>\n";
//		echo "<script type=\"text/javascript\">\n";
//		echo "\tvar Emaj = {\n";
//		echo "\tajax_time_refresh: {$refreshTime},\n";
//		echo "\tstr_start: {text:'{$lang['strstart']}',icon: '". $misc->icon('Execute') ."'},\n";
//		echo "\tstr_stop: {text:'{$lang['strstop']}',icon: '". $misc->icon('Stop') ."'},\n";
//		echo "\tload_icon: '". $misc->icon('Loading') ."',\n";
//		echo "\tserver:'{$_REQUEST['server']}',\n";
//		echo "\tdbname:'{$_REQUEST['database']}',\n";
//		echo "\tgroup:'{$_REQUEST['group']}',\n";
//		echo "\taction:'refresh_detail_group',\n";
//		echo "\terrmsg: '". str_replace("'", "\'", $lang['strconnectionfail']) ."'\n";
//		echo "\t};\n";
//		echo "</script>\n";

		$this->printPageHeader('emaj','emajgroups');

		$emajOK = $this->printEmajHeader("action=detail_group&amp;group=".urlencode($_REQUEST['group']),$this->lang['emajdetailgroup']);

		if ($emajOK){
			$this->printMsg($msg,$errMsg);

		// general information about the group
			$group = $this->emajdb->getGroup($_REQUEST['group']);
			$nbMarks = $group->fields['nb_mark'];

			$columns = array(
				'state' => array(
					'title' => $this->lang['emajstate'],
					'field' => field('group_state'),
//					'type'	=> 'callback',
//					'params'=> array('function' => 'renderGroupState')
				),
				'creationdatetime' => array(
					'title' => $this->lang['emajcreationdatetime'],
					'field' => field('group_creation_datetime'),
					'params'=> array('align' => 'center'),
				),
				'nbtbl' => array(
					'title' => $this->lang['emajnbtbl'],
					'field' => field('group_nb_table'),
					'type'  => 'numeric'
				),
				'nbseq' => array(
					'title' => $this->lang['emajnbseq'],
					'field' => field('group_nb_sequence'),
					'type'  => 'numeric'
				),
				'rollbackable' => array(
					'title' => $lang['strtype'],
					'field' => field('group_type'),
//					'type'	=> 'callback',
//					'params'=> array('function' => 'renderGroupType')
				),
				'nbmark' => array(
					'title' => $this->lang['emajnbmark'],
					'field' => field('nb_mark'),
					'type'  => 'numeric'
				),
				'logsize' => array(
					'title' => $this->lang['emajlogsize'],
					'field' => field('log_size'),
					'params'=> array('align' => 'center'),
				),
				'actions' => array(
					'title' => $lang['stractions'],
				),
			);

			$urlvars = $misc->getRequestVars();

			$groupActions = array(
				'startgroup' => array(
					'content' => $lang['strstart'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'start_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
				'stopgroup' => array(
					'content' => $lang['strstop'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'stop_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
				'setmarkgroup' => array(
					'content' => $this->lang['emajsetmark'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'set_mark_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
				'resetgroup' => array(
					'content' => $lang['strreset'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'reset_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
				'dropgroup' => array(
					'content' => $lang['strdrop'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'drop_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
			);
			if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
				$groupActions = array_merge($groupActions, array(
					'altergroup' => array(
						'content' => $lang['stralter'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'alter_group',
									'back' => 'detail',
									'group' => field('group_name'),
								))))
					),
				));
			};
			$groupActions = array_merge($groupActions, array(
				'content' => array(
					'content' => $this->lang['emajcontent'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'content_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
				'commentgroup' => array(
					'content' => $this->lang['emajsetcomment'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'comment_group',
								'back' => 'detail',
								'group' => field('group_name'),
							))))
				),
			));

		// save group's comment before call to printTable()
			$comment='';
			if (isset($group->fields['group_comment'])) {
				$comment=$group->fields['group_comment'];
			}

		// print group's characteristics
			echo "<h3>".sprintf($this->lang['emajgroupdesc'],$_REQUEST['group'])."</h3>\n";
//			$misc->printTable($group, $columns, $groupActions, 'detailGroup', 'no group, internal error !','groupPre');
			$misc->printTable($group, $columns, $groupActions, 'detailGroup', 'no group, internal error !');

		// display group's comment if exists
			if ($comment<>'') {
				echo "<p>{$lang['strcomment']} : ",$comment,"</p>\n";
			}

		// if there is at least 1 mark, list all marks for the group and propose statistics
			if ($nbMarks > 0) {

		// get marks from database
				$marks = $this->emajdb->getMarks($_REQUEST['group']);

				echo "<hr>";
				echo "<h3>".sprintf($this->lang['emajmarklst'],$_REQUEST['group'])."</h3>\n";
//			echo "<p><a id=\"control\" href=\"\"><img src=\"".$misc->icon('Refresh')."\" alt=\"{$lang['strrefresh']}\" title=\"{$lang['strrefresh']}\"/>&nbsp;{$lang['strrefresh']}</a></p>";
//			echo "<div id=\"data_block\">";
//			currentMarks();
//			echo "</div>\n";

				$columns = array(
					'mark' => array(
						'title' => $this->lang['emajmark'],
						'field' => field('mark_name'),
					),
					'datetime' => array(
						'title' => $this->lang['emajtimestamp'],
						'field' => field('mark_datetime'),
					),
					'state' => array(
						'title' => $this->lang['emajstate'],
						'field' => field('mark_state'),
//						'type'	=> 'callback',
//						'params'=> array('function' => 'renderMarkState','align' => 'center')
					),
					'logrows' => array(
						'title' => $this->lang['emajnbupdates'],
						'field' => field('mark_logrows'),
						'type'  => 'numeric'
					),
					'cumlogrows' => array(
						'title' => $this->lang['emajcumupdates'],
						'field' => field('mark_cumlogrows'),
						'type'  => 'numeric'
					),
					'actions' => array(
						'title' => $lang['stractions'],
					),
					'comment' => array(
						'title' => $lang['strcomment'],
						'field' => field('mark_comment'),
					),
				);

				$actions = array(
					'simrlbkmark' => array(
						'content' => $this->lang['emajsimrlbk'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'sim_rlbk_mark',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
					'rollbackgroup' => array(
						'content' => $this->lang['emajrlbk'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'rollback_group',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
					'renamemark' => array(
						'content' => $this->lang['emajrename'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'rename_mark_group',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
					'deletemark' => array(
						'content' => $lang['strdelete'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'delete_mark',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
					'deletebeforemark' => array(
						'content' => $this->lang['emajfirstmark'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'delete_before_mark',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
					'commentmark' => array(
						'content' => $this->lang['emajsetcomment'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'comment_mark_group',
									'back' => 'detail',
									'group' => field('mark_group'),
									'mark' => field('mark_name'),
								))))
					),
				);

			// reset previous_cumlogrows that will be used in markPre function
				$previous_cumlogrows = 0;
			// display the marks list
//				$misc->printTable($marks, $columns, $actions, 'marks', $this->lang['emajnomark'],'markPre');
				$misc->printTable($marks, $columns, $actions, 'marks', $this->lang['emajnomark']);

		// form for statistics
				echo "<a name=\"statform\"></a>";
				echo "<hr>";
				echo "<h3>{$this->lang['emajstatistics']}</h3>\n";

				echo "<style type=\"text/css\">[disabled]{color:#933;}</style>";
				echo "<form id=\"statistics_form\" action=\"plugin.php?plugin={$this->name}&amp;action=log_stat_group&amp;back=detail&amp;{$misc->href}\"";
				echo "  method=\"post\" enctype=\"multipart/form-data\">\n";

			// First mark defining the marks range to analyze
				echo "<p>{$this->lang['emajrangestart']}\n";
				echo "\t<select name=\"rangestart\" id=\"rangestart\">\n";
				foreach($marks as $r)
					echo "\t\t<option value=\"{$r['mark_name']}\" >{$r['mark_name']}</option>\n";
				echo "\t</select>\n";
			// JQuery to set the first mark as selected by default
				echo "\t<script type=\"text/javascript\">jQuery(\"#rangestart option:first-child\").attr(\"selected\", true);</script>";

			// Last mark defining the marks range to analyze
				echo "{$this->lang['emajrangeend']}\n";
				echo "\t<select name=\"rangeend\" id=\"rangeend\" >\n";
				echo "\t\t<option selected value=\"currentsituation\">{$this->lang['emajcurrentsituation']}</option>\n";
				foreach($marks as $r)
					echo "\t\t<option value=\"{$r['mark_name']}\" disabled=\"disabled\" >{$r['mark_name']}</option>\n";
				echo "\t</select>\n";
			// JQuery to remove the last mark as it cannot be selected as end mark
				echo "\t<script type=\"text/javascript\">jQuery(\"#rangeend option:last-child\").remove();</script>";
				echo "\t<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
				echo "\t<input type=\"submit\" name=\"globalstatgroup\" value=\"{$this->lang['emajglobalstat']}\" />\n";
				echo "\t<input type=\"submit\" name=\"detailedstatgroup\" value=\"{$this->lang['emajdetailedstat']}\" />\n";
				echo "</p></form>\n";

			// JQuery script to avoid rangestart > rangeend
				echo "<script type=\"text/javascript\">\n";
				echo "  $(\"#rangestart\").change(function () {\n";
				echo "    mark = $(\"#rangestart option:selected\").val();\n";
				echo "    todisable = false;\n";
				echo "    $(\"#rangeend option\").each(function(i){\n";
				echo "      if ($(this).val() == mark) { todisable = true; }\n";
				echo "      $(this).prop('disabled', todisable);\n";
				echo "    });\n";
				echo "  });\n";
				echo "  $(\"#rangeend\").change(function () {\n";
				echo "    mark = $(\"#rangeend option:selected\").val();\n";
				echo "    todisable = true;\n";
				echo "    if (mark == \"currentsituation\") {todisable = false;}\n";
				echo "    $(\"#rangestart option\").each(function(i){\n";
				echo "      $(this).prop('disabled', todisable);\n";
				echo "      if ($(this).val() == mark) { todisable = false; }\n";
				echo "    });\n";
				echo "  });\n";
				echo "</script>";
			}
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Define groups content
	 */
	function define_groups($msg = '', $errMsg = '') {
		global $misc, $lang;

		$this->printPageHeader('emaj','emajdefinegroups');

		if (!isset($_REQUEST['appschema'])) $_REQUEST['appschema'] = '';
		if (is_array($_REQUEST['appschema'])) $_REQUEST['appschema'] = $_REQUEST['appschema'][0];

		$emajOK = $this->printEmajHeader("action=define_groups&amp;appschema=".urlencode($_REQUEST['appschema']),$this->lang['emajgroupssetup']);

		if ($emajOK){
			$this->printMsg($msg,$errMsg);

		// Schemas list
			echo "<h3>{$this->lang['emajschemaslist']}</h3>\n";

			$schemas = $this->emajdb->getSchemas();

			$columns = array(
				'schema' => array(
					'title' => $lang['strschema'],
					'field' => field('nspname'),
					'url'   => "plugin.php?plugin={$this->name}&amp;action=define_groups&amp;back=define&amp;{$misc->href}&amp;",
					'vars'  => array('appschema' => 'nspname'),
				),
				'owner' => array(
					'title' => $lang['strowner'],
					'field' => field('nspowner'),
//					'type'	=> 'callback',
//					'params'=> array('function' => 'renderSchemaOwner'),
				),
				'comment' => array(
					'title' => $lang['strcomment'],
					'field' => field('nspcomment'),
				),
			);

			$actions = array ();

			$misc->printTable($schemas, $columns, $actions, 'defineGroupSchemas', $lang['strnoschemas']);

			echo "<hr>\n";

		// Tables and sequences for the selected schema, if any
			if (isset($_REQUEST['appschema']) && $_REQUEST['appschema'] != ''){

				echo "<h3>".sprintf($this->lang['emajtblseqofschema'],$_REQUEST['appschema'])."</h3>\n";
				$tblseq = $this->emajdb->getTablesSequences($_REQUEST['appschema']);

				$columns = array(
					'type' => array(
						'title' => $lang['strtype'],
						'field' => field('relkind'),
//					'type'	=> 'callback',
//					'params'=> array('function' => 'renderTblSeq'),
					),
					'appschema' => array(
						'title' => $lang['strschema'],
						'field' => field('nspname'),
					),
					'tblseq' => array(
						'title' => $lang['strname'],
						'field' => field('relname'),
					),
					'group' => array(
						'title' => $this->lang['emajgroup'],
						'field' => field('grpdef_group'),
					),
					'priority' => array(
						'title' => $this->lang['emajpriority'],
						'field' => field('grpdef_priority'),
						'params'=> array('align' => 'center'),
					),
				);
				if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
					$columns = array_merge($columns, array(
						'logschemasuffix' => array(
							'title' => $this->lang['emajlogschemasuffix'],
							'field' => field('grpdef_log_schema_suffix'),
						),
						'logdattsp' => array(
							'title' => $this->lang['emajlogdattsp'],
							'field' => field('grpdef_log_dat_tsp'),
						),
						'logidxtsp' => array(
							'title' => $this->lang['emajlogidxtsp'],
							'field' => field('grpdef_log_idx_tsp'),
						),
					));
				};
				$columns = array_merge($columns, array(
					'actions' => array(
						'title' => $lang['stractions'],
					),
					'owner' => array(
						'title' => $lang['strowner'],
						'field' => field('relowner'),
					),
					'tablespace' => array(
						'title' => $lang['strtablespace'],
						'field' => field('tablespace')
					),
					'comment' => array(
						'title' => $lang['strcomment'],
						'field' => field('relcomment'),
					),
				));

				$urlvars = $misc->getRequestVars();

				$actions = array(
					'multiactions' => array(
						'keycols' => array('appschema' => 'nspname', 'tblseq' => 'relname', 'group' => 'grpdef_group'),
						'url' => "plugin.php?plugin={$this->name}&amp;back=define",
					),
					'assign' => array(
						'content' => $this->lang['emajassign'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'assign_tblseq',
									'appschema' => field('nspname'),
									'tblseq' => field('relname'),
									'group' => field('grpdef_group'),
								)))),
						'multiaction' => 'assign_tblseq',
					),
					'remove' => array(
						'content' => $this->lang['emajremove'],
						'attr' => array (
							'href' => array (
								'url' => 'plugin.php',
								'urlvars' => array_merge($urlvars, array (
									'plugin' => $this->name,
									'action' => 'remove_tblseq',
									'appschema' => field('nspname'),
									'tblseq' => field('relname'),
									'group' => field('grpdef_group'),
								)))),
						'multiaction' => 'remove_tblseq',
					),
				);

//				$misc->printTable($tblseq, $columns, $actions, 'defineGroupTblseq', $lang['strnotables'],'tablePre');
				$misc->printTable($tblseq, $columns, $actions, 'defineGroupTblseq', $lang['strnotables']);

			}
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Display the status of past and in progress rollback operations
	 */
	function rlbk_activity($msg = '', $errMsg = '') {
		global $lang, $misc;

		$this->printPageHeader('emaj','emajmonitorrlbk');

		echo "<script src=\"plugins/Emaj/js/jquery.keyfilter-1.7.min.js\" type=\"text/javascript\"></script>\n";

		$emajOK = $this->printEmajHeader("action=rlbk_activity",$this->lang['emajrlbkoperations']);

		if ($emajOK){
			$this->printMsg($msg,$errMsg);

			if (!isset($_SESSION['emajRlbkNb'])) {
				$_SESSION['emajRlbkNb'] = 3;
			}
			if (!isset($_SESSION['emajRlbkRetention'])) {
				$_SESSION['emajRlbkRetention'] = 24;
			}
			if (!isset($_SESSION['emajnbrlbkchecked'])) {
				$nbRlbk = -1;
			} else {
				$nbRlbk = $_SESSION['emajRlbkNb'];
			}
			if (!isset($_SESSION['emajdurationchecked'])) {
				$rlbkRetention = -1;
			} else {
				$rlbkRetention = $_SESSION['emajRlbkRetention'];
			}

			// Get rollback information from the database
			$completedRlbks = $this->emajdb->getCompletedRlbk($nbRlbk, $rlbkRetention);
			$inProgressRlbks = $this->emajdb->getInProgressRlbk();

			$columnsCompletedRlbk = array(
				'rlbkId' => array(
					'title' => $this->lang['emajrlbkid'],
					'field' => field('rlbk_id'),
					'params'=> array('align' => 'right'),
				),
				'rlbkGroups' => array(
					'title' => $this->lang['emajgroups'],
					'field' => field('rlbk_groups_list'),
				),
				'rlbkStatus' => array(
					'title' => $this->lang['emajstate'],
					'field' => field('rlbk_status'),
				),
				'rlbkStartDateTime' => array(
					'title' => $this->lang['emajrlbkstart'],
					'field' => field('rlbk_start_datetime'),
					'params'=> array('align' => 'center'),
				),
				'rlbkEndDateTime' => array(
					'title' => $this->lang['emajrlbkend'],
					'field' => field('rlbk_end_datetime'),
					'params'=> array('align' => 'center'),
				),
				'rlbkDuration' => array(
					'title' => $this->lang['emajduration'],
					'field' => field('rlbk_duration'),
					'params'=> array('align' => 'center'),
				),
				'rlbkMark' => array(
					'title' => $this->lang['emajmark'],
					'field' => field('rlbk_mark'),
				),
				'rlbkMarkDateTime' => array(
					'title' => $this->lang['emajmarksetat'],
					'field' => field('rlbk_mark_datetime'),
				),
				'isLogged' => array(
					'title' => $this->lang['emajislogged'],
					'field' => field('rlbk_is_logged'),
					'params'=> array('align' => 'center'),
				),
				'rlbkNbSession' => array(
					'title' => $this->lang['emajnbsession'],
					'field' => field('rlbk_nb_session'),
					'params'=> array('align' => 'right'),
				),
				'rlbkNbTable' => array(
					'title' => $this->lang['emajnbproctable'],
					'field' => field('rlbk_eff_nb_table'),
					'params'=> array('align' => 'right'),
				),
				'rlbkNbSeq' => array(
					'title' => $this->lang['emajnbprocseq'],
					'field' => field('rlbk_nb_sequence'),
					'params'=> array('align' => 'right'),
				),
			);

			$columnsInProgressRlbk = array(
				'rlbkId' => array(
					'title' => $this->lang['emajrlbkid'],
					'field' => field('rlbk_id'),
					'params'=> array('align' => 'right'),
				),
				'rlbkGroups' => array(
					'title' => $this->lang['emajgroups'],
					'field' => field('rlbk_groups_list'),
				),
				'rlbkStatus' => array(
					'title' => $this->lang['emajstate'],
					'field' => field('rlbk_status'),
				),
				'rlbkStartDateTime' => array(
					'title' => $this->lang['emajrlbkstart'],
					'field' => field('rlbk_start_datetime'),
					'params'=> array('align' => 'center'),
				),
				'rlbkElapse' => array(
					'title' => $this->lang['emajcurrentduration'],
					'field' => field('rlbk_current_elapse'),
					'params'=> array('align' => 'center'),
				),
				'rlbkRemaining' => array(
					'title' => $this->lang['emajestimremaining'],
					'field' => field('rlbk_remaining'),
					'params'=> array('align' => 'center'),
				),
				'rlbkCompletionPct' => array(
					'title' => $this->lang['emajpctcompleted'],
					'field' => field('rlbk_completion_pct'),
					'params'=> array('align' => 'right'),
				),
				'rlbkMark' => array(
					'title' => $this->lang['emajmark'],
					'field' => field('rlbk_mark'),
				),
				'rlbkMarkDateTime' => array(
					'title' => $this->lang['emajmarksetat'],
					'field' => field('rlbk_mark_datetime'),
				),
				'isLogged' => array(
					'title' => $this->lang['emajislogged'],
					'field' => field('rlbk_is_logged'),
					'params'=> array('align' => 'center'),
				),
				'rlbkNbSession' => array(
					'title' => $this->lang['emajnbsession'],
					'field' => field('rlbk_nb_session'),
					'params'=> array('align' => 'right'),
				),
				'rlbkNbTable' => array(
					'title' => $this->lang['emajnbtabletoprocess'],
					'field' => field('rlbk_eff_nb_table'),
					'params'=> array('align' => 'right'),
				),
				'rlbkNbSeq' => array(
					'title' => $this->lang['emajnbseqtoprocess'],
					'field' => field('rlbk_nb_sequence'),
					'params'=> array('align' => 'right'),
				),
			);

			$actions = array();

			echo "<h3>{$this->lang['emajcompletedrlbk']}</h3>\n";

			// Form to setup parameters for completed rollback operations filtering
//			echo "<div style=\"margin-bottom:10px; padding:6px; border:1px dotted;\">\n";
			echo "<div style=\"margin-bottom:10px;\">\n";
			echo "<form action=\"plugin.php?plugin={$this->name}&amp;action=filterrlbk\" method=\"post\">\n";
			echo "{$this->lang['emajfilterrlbk1']} :&nbsp;&nbsp;\n";

				// mask-pnum class is used by jquery.filter to only accept digits
			echo "<input type=checkbox name=\"emajnbrlbkchecked\" id=\"nbrlbkchecked\"";
			if (isset($_SESSION['emajnbrlbkchecked'])) echo " checked";
			echo "/>\n<input name=\"emajRlbkNb\" size=\"2\" id=\"rlbkNb\" class=\"mask-pnum\" value=\"{$_SESSION['emajRlbkNb']}\"";
			if (!isset($_SESSION['emajnbrlbkchecked'])) echo " disabled";
			echo "/>\n{$this->lang['emajfilterrlbk2']}&nbsp;&nbsp;&nbsp;";

			echo "<input type=checkbox name=\"emajdurationchecked\" id=\"durationchecked\"";
			if (isset($_SESSION['emajdurationchecked'])) echo " checked";
			echo "/>\n {$this->lang['emajfilterrlbk3']} \n";
			echo "<input name=\"emajRlbkRetention\" size=\"3\" id=\"rlbkRetention\" class=\"mask-pnum\" value=\"{$_SESSION['emajRlbkRetention']}\"";
			if (!isset($_SESSION['emajdurationchecked'])) echo " disabled";
			echo "/>\n {$this->lang['emajfilterrlbk4']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

			echo $misc->form;
			echo "<input type=\"submit\" name=\"filterrlbk\" value=\"Filtrer\" />\n";
			echo "</form></div>\n";

			$misc->printTable($completedRlbks, $columnsCompletedRlbk, $actions, 'completedRlbk', $this->lang['emajnorlbk']);

			echo "<h3>{$this->lang['emajinprogressrlbk']}</h3>\n";
			$misc->printTable($inProgressRlbks, $columnsInProgressRlbk, $actions, 'inProgressRlbk', $this->lang['emajnorlbk']);

			// JQuery script to disable input field if the associated checkbox is not checked
			echo "<script type=\"text/javascript\">\n";
			echo "  $(\"#nbrlbkchecked\").bind('click', function () {\n";
			echo "    if ($(this).prop('checked')) {\n";
			echo "      $(\"#rlbkNb\").removeAttr('disabled');\n";
			echo "    } else {\n";
			echo "      $(\"#rlbkNb\").attr('disabled', true);\n";
			echo "    }\n";
			echo "  });\n";
			echo "  $(\"#durationchecked\").bind('click', function () {\n";
			echo "    if ($(this).prop('checked')) {\n";
			echo "      $(\"#rlbkRetention\").removeAttr('disabled');\n";
			echo "    } else {\n";
			echo "      $(\"#rlbkRetention\").attr('disabled', true);\n";
			echo "    }\n";
			echo "  });\n";
			echo "</script>\n";
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Change the filtering parameters for the display of completed rollback operations
	 */
	function filterrlbk() {

		if (isset($_POST['emajnbrlbkchecked'])) {
			if (isset($_POST['emajRlbkNb'])) 
				$_SESSION['emajRlbkNb'] = $_POST['emajRlbkNb'];
			$_SESSION['emajnbrlbkchecked'] = $_POST['emajnbrlbkchecked'];
		} else {
			unset($_SESSION['emajnbrlbkchecked']);
		}
		if (isset($_POST['emajdurationchecked'])) {
			if (isset($_POST['emajRlbkRetention'])) 
				$_SESSION['emajRlbkRetention'] = $_POST['emajRlbkRetention'];
			$_SESSION['emajdurationchecked'] = $_POST['emajdurationchecked'];
		} else {
			unset($_SESSION['emajdurationchecked']);
		}

		$this->rlbk_activity();
	}

	/**
	 * Checks E-Maj objects
	 */
	function check() {
		global $misc, $lang;

		$this->printPageHeader('emaj','emajcheck');

		$emajOK = $this->printEmajHeader("action=check",$this->lang['emajchecking']);

		if ($emajOK){

			echo "<h3></h3>\n";

			$messages = $this->emajdb->checkEmaj();

			if ($messages->recordCount() == 0) {
				echo "<p>No diagnostic message returned!</p>\n";
			} else {
				echo "<table>\n";
				echo "<tr>\n";
				// Display table header
				echo "<th class=\"data\">{$this->lang['emajdiagnostics']}</th>\n";
				echo "</tr>\n";

				// Display table rows
				$i = 0;
				while (!$messages->EOF) {
					$id = ($i % 2) + 1;
					echo "<tr class=\"data{$id}\">\n";

					// Display diagnostic
					echo "<td>";
					$val = $messages->fields['emaj_verify_all'];
					$icon = preg_match("/[Nn]o error /",$val) ? 'CheckConstraint' : 'CorruptedDatabase';
					echo "<img src=\"".$misc->icon($icon)."\" style=\"vertical-align:bottom;\" />";
// TODO : style
					echo $misc->printVal($val, null, array());
					echo "</td>\n";

					echo "</tr>\n";
					$messages->moveNext();
					$i++;
				}
				// Display table footer
				echo "</table>\n";
			}
//			$columns = array(
//				'message' => array(
//					'title' => $this->lang['emajdiagnostics'],
//					'field' => field('emaj_verify_all'),
//					'type'	=> 'callback',
//					'params'=> array('function' => array($this, 'renderDiagnostic'))
//				),
//			);

//			$actions = array ();

//			$misc->printTable($messages, $columns, $actions, 'checks');
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Displays the list of tables and sequences that composes a group
	 */
	function content_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$emajOK = $this->printEmajHeader("action=content_group&amp;group=".urlencode($_REQUEST['group']),$this->lang['emajcontentofagroup']);

		if ($emajOK){

		// navigation links
			echo "<ul class=\"navlink\">";
			echo "\t<li><a href=\"plugin.php?plugin={$this->name}&amp;action=detail_group&amp;group=",urlencode($_REQUEST['group']),"&amp;back=detail&amp;{$misc->href}\">{$this->lang['emajbackdetail']}</a></li>\n";
			echo "</ul>\n";

			echo "<h3>".sprintf($this->lang['emajgroupcontent'],$_REQUEST['group'])."</h3>\n";

			$groupContent = $this->emajdb->getContentGroup($_REQUEST['group']);

			$columns = array(
				'type' => array(
					'title' => $lang['strtype'],
					'field' => field('rel_kind'),
//					'type'	=> 'callback',
//					'params'=> array('function' => 'renderTblSeq')
				),
				'schema' => array(
					'title' => $lang['strschema'],
					'field' => field('rel_schema'),
					'url'   => "redirect.php?subject=schema&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'rel_schema'),
				),
				'tblseq' => array(
					'title' => $lang['strname'],
					'field' => field('rel_tblseq'),
					'url'	=> "redirect.php?subject=table&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'rel_schema', 'table' => 'rel_tblseq'),
				),
				'priority' => array(
					'title' => $this->lang['emajpriority'],
					'field' => field('rel_priority'),
					'params'=> array('align' => 'center'),
				),
			);
			if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
				$columns = array_merge($columns, array(
					'log_schema' => array(
						'title' => $this->lang['emajlogschema'],
						'field' => field('rel_log_schema'),
					),
					'log_dat_tsp' => array(
						'title' => $this->lang['emajlogdattsp'],
						'field' => field('rel_log_dat_tsp'),
					),
					'log_idx_tsp' => array(
						'title' => $this->lang['emajlogidxtsp'],
						'field' => field('rel_log_idx_tsp'),
					),
				));
			};
			$columns = array_merge($columns, array(
				'logsize' => array(
					'title' => $this->lang['emajlogsize'],
					'field' => field('log_size'),
					'params'=> array('align' => 'center'),
				),
			));

			$actions = array ();

			$misc->printTable($groupContent, $columns, $actions, 'groupContent');

		// navigation links
			echo "<ul class=\"navlink\">";
			echo "\t<li><a href=\"plugin.php?plugin={$this->name}&amp;action=detail_group&amp;group=",urlencode($_REQUEST['group']),"&amp;back=detail&amp;{$misc->href}\">{$this->lang['emajbackdetail']}</a></li>\n";
			echo "</ul>\n";
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Return statistical information simulating a rollback
	 */
	function sim_rlbk_mark() {
		global $misc, $lang;

		$this->printPageHeader();

		$emajOK = $this->printEmajHeader("action=sim_rlbk_mark&amp;group=".urlencode($_REQUEST['group'])."&amp;mark=".urlencode($_REQUEST['mark']),$this->lang['emajsimarlbk']);

		if ($emajOK){

			$globstat=$this->emajdb->getGlobalRlbkStatGroup($_REQUEST['group'],$_REQUEST['mark']);
			$rlbkDuration=$this->emajdb->estimateRollbackGroup($_REQUEST['group'],$_REQUEST['mark']);
			$stats=$this->emajdb->getLogStatGroup($_REQUEST['group'],$_REQUEST['mark'],'');

			echo "<p>",sprintf($this->lang['emajsimrlbktittle'], $misc->printVal($_REQUEST['group']), $misc->printVal($_REQUEST['mark'])),"</p>\n";

			echo "<table><tr>\n";
			echo "<th class=\"data\" colspan=3>{$this->lang['emajestimates']}</th>\n";
			echo "</tr><tr>\n";
			echo "<th class=\"data\">{$this->lang['emajsimrlbknbupd']}</th>";
			echo "<th class=\"data\">{$this->lang['emajsimrlbknbtbl']}</th>";
			echo "<th class=\"data\">{$this->lang['emajduration']}</th>\n";
			echo "</tr><tr class=\"data1\">\n";
			echo "<td><div style=\"text-align: center\">{$globstat->fields['sumrows']}</div></td>";
			echo "<td><div style=\"text-align: center\">{$globstat->fields['nbtables']}</div></td>";
			echo "<td><div style=\"text-align: center\">{$rlbkDuration}</div></td>\n";
			echo "</tr></table>\n";

			echo "<p></p>\n";
// TODO : utiliser des DIV avec margin à la place du paragraphe vide

			$columns = array(
				'schema' => array(
					'title' => $lang['strschema'],
					'field' => field('stat_schema'),
					'url'   => "redirect.php?subject=schema&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'stat_schema'),
				),
				'table' => array(
					'title' => $lang['strtable'],
					'field' => field('stat_table'),
					'url'	=> "redirect.php?subject=table&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'stat_schema', 'table' => 'stat_table'),
				),
				'nbrow' => array(
					'title' => $this->lang['emajstatrows'],
					'field' => field('stat_rows'),
					'type'  => 'numeric'
				),
			);
			$actions = array ();
			$misc->printTable($stats, $columns, $actions, 'simRlbk');

			echo "<ul class=\"navlink\">";
			echo "\t<li><a href=\"plugin.php?plugin={$this->name}&amp;&action=detail_group&amp;group=",urlencode($_REQUEST['group']),"&amp;back=detail&amp;{$misc->href}\">{$this->lang['emajbackdetail']}</a></li>\n";
			echo "</ul>\n";
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Show global or detailed log statistics between 2 marks or since a mark
	 */
	function log_stat_group() {
		global $misc, $lang;

		$this->printPageHeader();

		if (isset($_REQUEST['globalstatgroup'])) {
			$globalStat = true; $detailedStat = false;
			$urlExt = 'globalstatgroup='.urlencode($_REQUEST['globalstatgroup']);
		}
		if (isset($_REQUEST['detailedstatgroup'])) {
			$globalStat = false; $detailedStat = true;
			$urlExt = 'detailedstatgroup='.urlencode($_REQUEST['detailedstatgroup']);
		}

		$emajOK = $this->printEmajHeader("action=log_stat_group&amp;group=".urlencode($_REQUEST['group'])."&amp;rangestart=".urlencode($_REQUEST['rangestart'])."&amp;rangeend=".urlencode($_REQUEST['rangeend'])."&amp;{$urlExt}",$this->lang['emajshowstat']);

		if ($emajOK){

			echo "<ul class=\"navlink\">";
			echo "\t<li><a href=\"plugin.php?plugin={$this->name}&amp;&action=detail_group&amp;group=",urlencode($_REQUEST['group']),"&amp;back=detail&amp;{$misc->href}\">{$this->lang['emajbackdetail']}</a></li>\n";
			echo "</ul>\n";

			if ($_REQUEST['rangeend']=='currentsituation'){
				$w1 = $this->lang['emajlogstatcurrentsituation'];
			}else{
				$w1 = $this->lang['emajlogstatmark'].$_REQUEST['rangeend'];
			}
			echo "<h3>", sprintf($this->lang['emajlogstattittle'], $misc->printVal($_REQUEST['rangestart']), $misc->printVal($w1), $misc->printVal($_REQUEST['group'])), "</h3>\n";

			if ($globalStat){
				if ($_REQUEST['rangeend']=='currentsituation'){
					$stats = $this->emajdb->getLogStatGroup($_REQUEST['group'],$_REQUEST['rangestart'],'');
				}else{
					$stats = $this->emajdb->getLogStatGroup($_REQUEST['group'],$_REQUEST['rangestart'],$_REQUEST['rangeend']);
				}
			}else{
				if ($_REQUEST['rangeend']=='currentsituation'){
					$stats = $this->emajdb->getDetailedLogStatGroup($_REQUEST['group'],$_REQUEST['rangestart'],'');
				}else{
					$stats = $this->emajdb->getDetailedLogStatGroup($_REQUEST['group'],$_REQUEST['rangestart'],$_REQUEST['rangeend']);
				}
			}

			$urlvars = $misc->getRequestVars();

			$columns = array(
				'schema' => array(
					'title' => $lang['strschema'],
					'field' => field('stat_schema'),
					'url'   => "redirect.php?subject=schema&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'stat_schema'),
				),
				'table' => array(
					'title' => $lang['strtable'],
					'field' => field('stat_table'),
					'url'	=> "redirect.php?subject=table&amp;{$misc->href}&amp;",
					'vars'  => array('schema' => 'stat_schema', 'table' => 'stat_table'),
				),
			);
			if ($detailedStat){
				$columns = array_merge($columns, array(
					'role' => array(
						'title' => $lang['strrole'],
						'field' => field('stat_role'),
					),
					'statement' => array(
						'title' => $this->lang['emajstatverb'],
						'field' => field('stat_verb'),
					),
				));
			}
			$columns = array_merge($columns, array(
				'nbrow' => array(
					'title' => $this->lang['emajstatrows'],
					'field' => field('stat_rows'),
					'type'  => 'numeric'
				),
				'actions' => array(
					'title' => $lang['stractions'],
				),
			));

			$actions = array(
				'sql' => array(
					'content' => $lang['strsql'],
					'attr' => array (
						'href' => array (
							'url' => 'plugin.php',
							'urlvars' => array_merge($urlvars, array (
								'plugin' => $this->name,
								'action' => 'call_sqledit',
								'subject' => 'table',
								'sqlquery' => field('sql_text'),
								'paginate' => 'true',
					)))),
				),
			);

			echo "<div id=\"statTable\">\n";
			$misc->printTable($stats, $columns, $actions, 'stats', $this->lang['emajnostat']);
			echo "</div>\n";

// dynamicly change the behaviour of the SQL link using JQuery code: open a new window
			$sql_window_id = htmlentities('sqledit:'.$_REQUEST['server']);
			echo "<script type=\"text/javascript\">
				$(\"#statTable a:contains('SQL')\").attr('target','emaj_sqledit');
				$(\"#statTable a:contains('SQL')\").click(function() {
					window.open($(this).attr('href'),'{$sql_window_id}','toolbar=no,width=700,height=500,resizable=yes,scrollbars=yes').focus();
					return false;
				});
				</script>";

			echo "<ul class=\"navlink\">";
			echo "\t<li><a href=\"plugin.php?plugin={$this->name}&amp;&action=detail_group&amp;group=",urlencode($_REQUEST['group']),"&amp;back=detail&amp;{$misc->href}\">{$this->lang['emajbackdetail']}</a></li>\n";
			echo "</ul>\n";
		}

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Prepare insert a table/sequence into a group: ask for priority and confirmation
	 */
	function assign_tblseq() {
		global $misc, $lang;

		// Test at least 1 table/sequence is to be processed
		if (empty($_REQUEST['tblseq']) && empty($_REQUEST['ma'])) {
			$this->define_groups($this->lang['emajspecifytblseqtoassign']);
			exit();
		}
		// Test all tables/sequences to process are not yet assigned to a group
		if (isset($_REQUEST['ma'])) {
			foreach($_REQUEST['ma'] as $t) {
				$a = unserialize(htmlspecialchars_decode($t, ENT_QUOTES));
				if ($a['group'] != ''){
					$this->define_groups('',sprintf($this->lang['emajtblseqyetgroup'],$a['appschema'],$a['tblseq']));
					exit();
				}
			}
		}

		$this->printPageHeader('emaj','emajdefinegroups');

		$misc->printTitle($this->lang['emajassignatblseq']);

		echo "<script src=\"plugins/Emaj/js/jquery.keyfilter-1.7.min.js\" type=\"text/javascript\"></script>\n";

		// Get group names already known in emaj_group_def table
		$knownGroups = $this->emajdb->getKnownGroups();

		// Get log schema suffix already known in emaj_group_def table
		if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
			$knownSuffix = $this->emajdb->getKnownSuffix();
		}

		// Get tablespaces the current user can see
		if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
			$knownTsp = $this->emajdb->getKnownTsp();
		}

		$lst = '';
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<input type=\"hidden\" name=\"action\" value=\"assign_tblseq_ok\" />\n";

		if (isset($_REQUEST['ma'])) {
		// multiple assign
			foreach($_REQUEST['ma'] as $t) {
				$a = unserialize(htmlspecialchars_decode($t, ENT_QUOTES));
				echo "<input type=\"hidden\" name=\"appschema[]\" value=\"", htmlspecialchars($a['appschema']), "\" />\n";
				echo "<input type=\"hidden\" name=\"tblseq[]\" value=\"", htmlspecialchars($a['tblseq']), "\" />\n";
				$lst .= "<br>- {$a['appschema']}.{$a['tblseq']}";
			}
		}else{

		// single assign
			echo "<input type=\"hidden\" name=\"appschema\" value=\"", htmlspecialchars($_REQUEST['appschema']), "\" />\n";
			echo "<input type=\"hidden\" name=\"tblseq\" value=\"", htmlspecialchars($_REQUEST['tblseq']), "\" />\n";
			$lst = "{$_REQUEST['appschema']}.{$_REQUEST['tblseq']}";
		}

		echo "<p>", sprintf($this->lang['emajconfirmassigntblseq'], $lst), "</p>\n";

		echo "<table>\n";
		echo "<tr><th class=\"data left required\" rowspan=2>{$this->lang['emajgroup']}</th>";
		echo "<td class=\"data1\"><input id=\"groupInput\" type=\"text\" name=\"group\" value=\"\"/><span style=\"font-size: smaller; vertical-align: super;\"> (1)</span></td></tr>\n";
		echo "<tr><td><select id=\"groupList\" name=\"group1\"><option value=\"new_group\">{$this->lang['emajnewgroup']}</option>\n";
		if ($knownGroups->recordCount() > 0) {
			foreach($knownGroups as $r)
				echo "<option value=\"{$r['group_name']}\">{$r['group_name']}</option>\n";
		}
		echo "</select></td></tr>\n";
		// mask-pnum class is used by jquery.filter to only accept digits
		echo "<tr><th class=\"data left\">{$this->lang['emajenterpriority']}</th>";
		echo "<td class=\"data1\"><input type=\"text\" name=\"priority\" size=9 maxlength=9 value=\"\" class=\"mask-pnum\"/> <span style=\"font-size: smaller; vertical-align: super;\"> (2)</span></td></tr>\n";

		if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
			echo "<tr><th class=\"data left\" rowspan=2>{$this->lang['emajenterlogschema']}</th>";
			echo "<td class=\"data1\"><input type=\"text\" id=\"suffixInput\" name=\"suffix\" value=\"\"/><span style=\"font-size: smaller; vertical-align: super;\"> (3)</span></td></tr>\n";
			echo "<tr><td><select id=\"suffixList\" name=\"suffix1\">\n";
			echo "\t\t<option value=\"new_log_schema_suffix\">{$this->lang['emajnewsuffix']}</option>\n";
			if ($knownSuffix->recordCount() > 0) {
				foreach($knownSuffix as $r)
					echo "\t\t<option value=\"{$r['known_suffix']}\">{$r['known_suffix']}</option>\n";
			}
			echo "\t</select></td></tr>\n";

			echo "<tr><th class=\"data left\" rowspan=2>{$this->lang['emajenterlogdattsp']}</th>";
			echo "<td class=\"data1\"><input type=\"text\" id=\"logdattspInput\" name=\"logdattsp\" value=\"\"/></td></tr>\n";
			echo "<tr><td><select id=\"logdattspList\" name=\"logdattsp1\">\n";
			echo "\t\t<option value=\"new_log_dat_tsp\">{$this->lang['emajnewtsp']}</option>\n";
			if ($knownTsp->recordCount() > 0) {
				foreach($knownTsp as $r)
					echo "\t\t<option value=\"{$r['spcname']}\">{$r['spcname']}</option>\n";
			}
			echo "\t</select></td></tr>\n";

			echo "<tr><th class=\"data left\" rowspan=2>{$this->lang['emajenterlogidxtsp']}</th>";
			echo "<td class=\"data1\"><input type=\"text\" id=\"logidxtspInput\" name=\"logidxtsp\" value=\"\"/></td></tr>\n";
			echo "<tr><td><select id=\"logidxtspList\" name=\"logidxtsp1\">\n";
			echo "\t\t<option value=\"new_log_idx_tsp\">{$this->lang['emajnewtsp']}</option>\n";
			if ($knownTsp->recordCount() > 0) {
				foreach($knownTsp as $r)
					echo "\t\t<option value=\"{$r['spcname']}\">{$r['spcname']}</option>\n";
			}
			echo "\t</select></td></tr>\n";

		}else{
			echo "<p><input type=\"hidden\" name=\"suffix\" value=\"\" />\n";
			echo "<p><input type=\"hidden\" name=\"logdattsp\" value=\"\" />\n";
			echo "<p><input type=\"hidden\" name=\"logidxtsp\" value=\"\" />\n";
		};
		echo "</table>\n";

		echo $misc->form;
		echo "<p><span style=\"font-size: smaller;\">(1) </span>{$this->lang['emajrequired']}<br><span style=\"font-size: smaller;\">(2) </span> {$this->lang['emajpriorityhelp']}";
		if ($this->emajdb->getNumEmajVersion() >= 10000){			// version >= 1.0.0
			echo "<br><span style=\"font-size: smaller;\">(3) </span>{$this->lang['emajlogschemahelp']}";
		}
		echo"</p>\n";
		echo "<p><input type=\"submit\" name=\"assigntblseq\" value=\"{$this->lang['emajassign']}\" id=\"ok\" disabled=\"disabled\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		// JQuery script to only enable the submit button when the group name is not empty
		echo "  $(\"#groupInput\").keyup(function (data) {\n";
		echo "    if ($(this).val() != \"\") { $(\"#ok\").removeAttr(\"disabled\"); }\n";
		echo "      else { $(\"#ok\").attr(\"disabled\", \"disabled\"); }\n";
		echo "  });\n";
		// JQuery script to link input fields and associated list boxes
		echo "  $(\"#groupList\").change(function () { $(\"#groupInput\").val($(\"#groupList option:selected\").text()); $(\"#ok\").removeAttr(\"disabled\");});\n";
		echo "  $(\"#groupInput\").keyup(function () { $(\"#groupList option:first-child\").attr(\"selected\", true); });\n";
		echo "  $(\"#suffixList\").change(function () { $(\"#suffixInput\").val($(\"#suffixList option:selected\").text()); });\n";
		echo "  $(\"#suffixInput\").keyup(function () { $(\"#suffixList option:first-child\").attr(\"selected\", true); });\n";
		echo "  $(\"#logdattspList\").change(function () { $(\"#logdattspInput\").val($(\"#logdattspList option:selected\").text()); });\n";
		echo "  $(\"#logdattspInput\").keyup(function () { $(\"#logdattspList option:first-child\").attr(\"selected\", true); });\n";
		echo "  $(\"#logidxtspList\").change(function () { $(\"#logidxtspInput\").val($(\"#logidxtspList option:selected\").text()); });\n";
		echo "  $(\"#logidxtspInput\").keyup(function () { $(\"#logidxtspList option:first-child\").attr(\"selected\", true); });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform table/sequence insertion into a tables group
	 */
	function assign_tblseq_ok() {
		global $lang, $data;

	// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {$this->define_groups(); exit();}

		if (is_array($_POST['tblseq'])) {
		// multiple assignement
			$status = $data->beginTransaction();
			if ($status == 0) {
				for($i = 0; $i < sizeof($_POST['tblseq']); ++$i)
				{
					$status = $this->emajdb->assignTblSeq($_POST['appschema'][$i],$_POST['tblseq'][$i],$_POST['group'],
												$_POST['priority'], $_POST['suffix'], $_POST['logdattsp'], $_POST['logidxtsp']);
					if ($status != 0) {
						$data->endTransaction();
						define_groups('',$this->lang['emajmodifygrouperr']);
						return;
					}
				}
			}
			if($data->endTransaction() == 0)
				$this->define_groups($this->lang['emajmodifygroupok']);
			else
				$this->define_groups('',$this->lang['emajmodifygrouperr']);

		}else{

		// single assignement
			$status = $this->emajdb->assignTblSeq($_POST['appschema'],$_POST['tblseq'],$_POST['group'],
										$_POST['priority'], $_POST['suffix'], $_POST['logdattsp'], $_POST['logidxtsp']);
			if ($status == 0)
				$this->define_groups($this->lang['emajmodifygroupok']);
			else
				$this->define_groups('',$this->lang['emajmodifygrouperr']);
		}
	}

	/**
	 * Prepare remove a table/sequence from a group: ask for confirmation
	 */
	function remove_tblSeq() {
		global $misc, $lang;

		// Test at least 1 table/sequence is to be processed
		if (empty($_REQUEST['tblseq']) && empty($_REQUEST['ma'])) {
			$this->define_groups($this->lang['emajspecifytblseqtoremove']);
			exit();
		}
		// Test all tables/sequences to process are already assigned to a group
		if (isset($_REQUEST['ma'])) {
			foreach($_REQUEST['ma'] as $t) {
				$a = unserialize(htmlspecialchars_decode($t, ENT_QUOTES));
				if ($a['group'] == ''){
					$this->define_groups('',sprintf($this->lang['emajtblseqnogroup'],$a['appschema'],$a['tblseq']));
					exit();
				}
			}
		}

		$this->printPageHeader('emaj','emajdefinegroups');

		$misc->printTitle($this->lang['emajremoveatblseq']);

		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"remove_tblseq_ok\" />\n";

		if (isset($_REQUEST['ma'])) {
		// multiple removal
			foreach($_REQUEST['ma'] as $t) {
				$a = unserialize(htmlspecialchars_decode($t, ENT_QUOTES));
				echo '<p>', sprintf($this->lang['emajconfirmremovetblseq'], $misc->printVal($a['appschema']), $misc->printVal($a['tblseq']), $misc->printVal($a['group'])), "</p>\n";
				echo "<input type=\"hidden\" name=\"appschema[]\" value=\"", htmlspecialchars($a['appschema']), "\" />\n";
				echo "<input type=\"hidden\" name=\"tblseq[]\" value=\"", htmlspecialchars($a['tblseq']), "\" />\n";
				echo "<input type=\"hidden\" name=\"group[]\" value=\"", htmlspecialchars($a['group']), "\" />\n";
			}

		}else {

		// single removal
			echo "<p>", sprintf($this->lang['emajconfirmremovetblseq'], $misc->printVal($_REQUEST['appschema']), $misc->printVal($_REQUEST['tblseq']), $misc->printVal($_REQUEST['group'])), "</p>\n";
			echo "<input type=\"hidden\" name=\"appschema\" value=\"", htmlspecialchars($_REQUEST['appschema']), "\" />\n";
			echo "<input type=\"hidden\" name=\"tblseq\" value=\"", htmlspecialchars($_REQUEST['tblseq']), "\" />\n";
			echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		}

		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"removetblseq\" value=\"{$this->lang['emajremove']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform table/sequence removal from a tables group
	 */
	function remove_tblseq_ok() {
		global $lang, $data;

	// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {$this->define_groups(); exit();}

		if (is_array($_POST['tblseq'])) {
		// multiple removal
			$status = $data->beginTransaction();
			if ($status == 0) {
				for($i = 0; $i < sizeof($_POST['tblseq']); ++$i)
				{
					$status = $this->emajdb->removeTblSeq($_POST['appschema'][$i],$_POST['tblseq'][$i],$_POST['group'][$i]);
					if ($status != 0) {
						$data->endTransaction();
						$this->define_groups('',$this->lang['emajmodifygrouperr']);
						return;
					}
				}
			}
			if($data->endTransaction() == 0)
				$this->define_groups($this->lang['emajmodifygroupok']);
			else
				$this->define_groups('',$this->lang['emajmodifygrouperr']);

		}else{
		// single removal
			$status = $this->emajdb->removeTblSeq($_POST['appschema'],$_POST['tblseq'],$_POST['group']);

			if ($status == 0)
				$this->define_groups($this->lang['emajmodifygroupok']);
			else
				$this->define_groups('',$this->lang['emajmodifygrouperr']);
		}
	}

	/**
	 * Prepare create group: ask for confirmation
	 */
	function create_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajcreateagroup']);

		echo "<p>", sprintf($this->lang['emajconfirmcreategroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"create_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "{$this->lang['emajgrouptype']} : ";
		echo "<input type=\"radio\" name=\"grouptype\" value=\"rollbackable\" checked>{$this->lang['emajrollbackable']}";
		echo "<input type=\"radio\" name=\"grouptype\" value=\"auditonly\">{$this->lang['emajauditonly']}\n";
		echo "</p><p>";
		echo "<input type=\"submit\" name=\"creategroup\" value=\"{$lang['strcreate']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform create_group
	 */
	function create_group_ok() {
		global $lang, $_reload_browser;

	// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {$this->list_groups(); exit();}

		$status = $this->emajdb->createGroup($_POST['group'],$_POST['grouptype']=='rollbackable');
		if ($status > 0){
			$_reload_browser = true;
			$this->list_groups(sprintf($this->lang['emajcreategroupok'],$_POST['group']));
		}else
			$this->list_groups('',sprintf($this->lang['emajcreategrouperr'],$_POST['group']));
	}

	/**
	 * Prepare drop group: ask for confirmation
	 */
	function drop_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajdropagroup']);

		echo "<p>", sprintf($this->lang['emajconfirmdropgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"drop_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"dropgroup\" value=\"{$lang['strdrop']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform drop group
	 */
	function drop_group_ok() {
		global $lang, $_reload_browser;

	// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}

	// Check the group is always in IDLE state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'IDLE') {
			detailGroup($this->lang['emajgroupnotidle'].' '.$this->lang['emajcantdrpgroup']);
			return;
		}
	// OK
		$status = $this->emajdb->dropGroup($_POST['group']);
		if ($status > 0){
			$_reload_browser = true;
			$this->list_groups(sprintf($this->lang['emajdropgroupok'],$_POST['group']));
		}else
			$this->list_groups('',sprintf($this->lang['emajdropgrouperr'],$_POST['group']));
	}

	/**
	 * Prepare alter group: ask for confirmation
	 */
	function alter_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajalteragroup']);

		echo "<p>", sprintf($this->lang['emajconfirmaltergroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"alter_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"altergroup\" value=\"{$lang['stralter']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform alter group
	 */
	function alter_group_ok() {
		global $lang, $_reload_browser;

	// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}

	// Check the group is always in IDLE state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'IDLE') {
			$this->detail_group('',$this->lang['emajgroupnotidle'].' '.$this->lang['emajcantaltergroup']);
			return;
		}
	// OK
		$status = $this->emajdb->alterGroup($_POST['group']);
		if ($status > 0){
			$_reload_browser = true;
			if ($_POST['back'] == 'list') {
				$this->list_groups(sprintf($this->lang['emajaltergroupok'],$_POST['group']));
			}else{
				$this->detail_group(sprintf($this->lang['emajaltergroupok'],$_POST['group']));
			}
		}else
			if ($status == 0){
				$_reload_browser = true;
				if ($_POST['back'] == 'list') {
					$this->list_groups(sprintf($this->lang['emajalternogroup'],$_POST['group']));
				}else{
					$this->detail_group(sprintf($this->lang['emajalternogroup'],$_POST['group']));
				}
			}else
				if ($_POST['back'] == 'list') {
					$this->list_groups('',sprintf($this->lang['emajaltergrouperr'],$_POST['group']));
				}else{
					$this->detail_group('',sprintf($this->lang['emajaltergrouperr'],$_POST['group']));
				}
	}

	/**
	 * Prepare comment group: ask for comment and confirmation
	 */
	function comment_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajcommentagroup']);

		$group = $this->emajdb->getGroup($_REQUEST['group']);

		echo "<p>", sprintf($this->lang['emajcommentgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left\">{$lang['strcomment']}</th>\n";
		echo "<td class=\"data1\"><input name=\"comment\" size=\"100\" value=\"",
			htmlspecialchars($group->fields['group_comment']), "\" /></td></tr>\n";
		echo "</table>\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"comment_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"commentgroup\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform comment group
	 */
	function comment_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}

		$status = $this->emajdb->setCommentGroup($_POST['group'],$_POST['comment']);
		if ($status >= 0)
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajcommentgroupok'],$_POST['group']));
			}else{
				$this->detail_group(sprintf($this->lang['emajcommentgroupok'],$_POST['group']));
			}
		else
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajcommentgrouperr'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajcommentgrouperr'],$_POST['group']));
			}
	}

	/**
	 * Prepare start group: enter the initial mark name and confirm
	 */
	function start_group($msg = '', $errMsg = '') {
		global $misc, $lang;

		if (!isset($_POST['mark'])) $_POST['mark'] = '';

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajstartagroup']);
		$this->printMsg($msg,$errMsg);

		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p>", sprintf($this->lang['emajconfirmstartgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left required\" style=\"width: 100px\">{$this->lang['emajinitmark']}</th>\n";
		echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"",
			htmlspecialchars($_POST['mark']), "\" id=\"mark\" /></td></tr>\n";
		echo "</table>\n";
		echo "<p><input type=checkbox name=\"resetlog\" checked/>{$this->lang['emajoldlogsdeletion']}</p>\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"start_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" value=\"{$lang['strok']}\" id=\"ok\" disabled=\"disabled\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		echo "  $(document).ready(function () {\n";
		echo "    $(\"#mark\").keyup(function (data) {\n";
		echo "      if ($(this).val() != \"\") {\n";
		echo "        $(\"#ok\").removeAttr(\"disabled\");\n";
		echo "      } else {\n";
		echo "        $(\"#ok\").attr(\"disabled\", \"disabled\");\n";
		echo "      }\n";
		echo "    });\n";
		echo "  });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform start group
	 */
	function start_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}
		// Check the group is always in IDLE state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'IDLE') {
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajcantstartgroup'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajcantstartgroup'],$_POST['mark']));
			}
			return;
		}
		// If old marks are not deleted, check the supplied mark is valid for the group
		if (!isSet($_POST['resetlog']) && !$this->emajdb->isNewMarkValidGroup($_POST['group'],$_POST['mark'])) {
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}
			return;
		}
		// OK
		$status = $this->emajdb->startGroup($_POST['group'],$_POST['mark'],isSet($_POST['resetlog']));
		if ($status > 0)
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajstartgroupok'],$_POST['group'],$_POST['mark']));
			}else{
				$this->detail_group(sprintf($this->lang['emajstartgroupok'],$_POST['group'],$_POST['mark']));
			}
		else
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajstartgrouperr'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajstartgrouperr'],$_POST['group']));
			}
	}

	/**
	 * Prepare start groups: enter the initial mark name and confirm
	 */
	function start_groups($msg = '', $errMsg = '') {
		global $misc, $lang;

		if (!isset($_REQUEST['ma'])) {
			$this->list_groups('',$this->lang['emajnoselectedgroup']);
			return;
		}
		if (!isset($_POST['mark'])) $_POST['mark'] = '';

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajstartgroups']);
		$this->printMsg($msg,$errMsg);

		// build the groups list
		$groupsList='';
		foreach($_REQUEST['ma'] as $v) {
			$a = unserialize(htmlspecialchars_decode($v, ENT_QUOTES));
			$groupsList.=$a['group'].', ';
		}
		$groupsList=substr($groupsList,0,strlen($groupsList)-2);
		// send form
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p>", sprintf($this->lang['emajconfirmstartgroups'], $misc->printVal($groupsList)), "</p>\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left required\" style=\"width: 100px\">{$this->lang['emajinitmark']}</th>\n";
		echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"",
			htmlspecialchars($_POST['mark']), "\" id=\"mark\" /></td></tr>\n";
		echo "</table>\n";
		echo "<p><input type=checkbox name=\"resetlog\" checked/>{$this->lang['emajoldlogsdeletion']}</p>\n";
		echo "<input type=\"hidden\" name=\"groups\" value=\"", htmlspecialchars($groupsList), "\" />\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"start_groups_ok\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" value=\"{$lang['strok']}\" id=\"ok\" disabled=\"disabled\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		echo "  $(document).ready(function () {\n";
		echo "    $(\"#mark\").keyup(function (data) {\n";
		echo "      if ($(this).val() != \"\") {\n";
		echo "        $(\"#ok\").removeAttr(\"disabled\");\n";
		echo "      } else {\n";
		echo "        $(\"#ok\").attr(\"disabled\", \"disabled\");\n";
		echo "      }\n";
		echo "    });\n";
		echo "  });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform start groups
	 */
	function start_groups_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->list_groups(); exit(); }

		// Check the groups are always in IDLE state
		$groups=explode(', ',$_POST['groups']);
		foreach($groups as $g) {
			if ($this->emajdb->getGroup($g)->fields['group_state'] != 'IDLE'){
				$this->list_groups('',sprintf($this->lang['emajcantstartgroups'],$_POST['groups'],$g));
				return;
			}
		}
		// If old marks are not deleted, check the supplied mark is valid for the groups
		if (!isSet($_POST['resetlog']) && !$this->emajdb->isNewMarkValidGroups($_POST['groups'],$_POST['mark'])) {
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}
			return;
		}
		// OK
		$status = $this->emajdb->startGroups($_POST['groups'],$_POST['mark'],isSet($_POST['resetlog']));
		if ($status > 0)
			if ($_POST['back']=='list')
				$this->list_groups(sprintf($this->lang['emajstartgroupsok'],$_POST['groups'],$_POST['mark']));
		else
			if ($_POST['back']=='list')
				$this->list_groups('',sprintf($this->lang['emajstartgroupserr'],$_POST['groups']));
	}

	/**
	 * Prepare stop group: ask for confirmation
	 */
	function stop_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajstopagroup']);

		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p>", sprintf($this->lang['emajconfirmstopgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		if ($this->emajdb->getNumEmajVersion() >= 10000){					// version >= 1.0.0
			echo "<table>\n";
			echo "<tr><th class=\"data left\" style=\"width: 100px\">{$this->lang['emajstopmark']}</th>\n";
			echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"STOP_%\" /></td></tr>\n";
			echo "</table>\n";
			echo "<p><input type=checkbox name=\"forcestop\" />{$this->lang['emajforcestop']}</p>\n";
		}else{
			echo "<input type=\"hidden\" name=\"mark\" value=\"\" />\n";
		}
		echo "<p><input type=\"hidden\" name=\"action\" value=\"stop_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"stopgroup\" value=\"{$lang['strok']}\"/>\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform stop_group
	 */
	function stop_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}
		// Check the group is always in LOGGING state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'LOGGING'){
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajcantstopgroup'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajcantstopgroup'],$_POST['group']));
			}
			return;
		}
		// OK
		$status = $this->emajdb->stopGroup($_POST['group'],$_POST['mark'],isSet($_POST['forcestop']));
		if ($status > 0)
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajstopgroupok'],$_POST['group']));
			}else{
				$this->detail_group(sprintf($this->lang['emajstopgroupok'],$_POST['group']));
			}
		else
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajstopgrouperr'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajstopgrouperr'],$_POST['group']));
			}
	}

	/**
	 * Prepare stop group: ask for confirmation
	 */
	function stop_groups() {
		global $misc, $lang;

		if (!isset($_REQUEST['ma'])) {
			$this->list_groups('',$this->lang['emajnoselectedgroup']);
			return;
		}

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajstopgroups']);

		// build the groups list
		$groupsList='';
		foreach($_REQUEST['ma'] as $v) {
			$a = unserialize(htmlspecialchars_decode($v, ENT_QUOTES));
			$groupsList.=$a['group'].', ';
		}
		$groupsList=substr($groupsList,0,strlen($groupsList)-2);
		// send form
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p>", sprintf($this->lang['emajconfirmstopgroups'], $misc->printVal($groupsList)), "</p>\n";
		if ($this->emajdb->getNumEmajVersion() >= 10000){					// version >= 1.0.0
			echo "<table>\n";
			echo "<tr><th class=\"data left\" style=\"width: 100px\">{$this->lang['emajstopmark']}</th>\n";
			echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"STOP_%\" /></td></tr>\n";
			echo "</table>\n";
		}else{
			echo "<input type=\"hidden\" name=\"mark\" value=\"\" />\n";
		}
		echo "<p><input type=\"hidden\" name=\"action\" value=\"stop_groups_ok\" />\n";
		echo "<input type=\"hidden\" name=\"groups\" value=\"", htmlspecialchars($groupsList), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"stopgroups\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform stop_groups
	 */
	function stop_groups_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->list_groups(); exit(); }

		// Check the groups are always in LOGGING state
		$groups=explode(', ',$_POST['groups']);
		foreach($groups as $g) {
			if ($this->emajdb->getGroup($g)->fields['group_state'] != 'LOGGING') {
				$this->list_groups('',sprintf($this->lang['emajcantstopgroups'],$_POST['groups'],$g));
				return;
			}
		}
		// OK
		$status = $this->emajdb->stopGroups($_POST['groups'],$_POST['mark']);
		if ($status > 0)
			$this->list_groups(sprintf($this->lang['emajstopgroupsok'],$_POST['groups']));
		else
			$this->list_groups('',sprintf($this->lang['emajstopgroupserr'],$_POST['groups']));
	}

	/**
	 * Prepare reset group: ask for confirmation
	 */
	function reset_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajresetagroup']);

		echo "<p>", sprintf($this->lang['emajconfirmresetgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"reset_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"resetgroup\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform reset group
	 */
	function reset_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}
		// Check the group is always in IDLE state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'IDLE') {
			if ($_POST['back']=='list') {
				$this->list_groups('',"{$this->lang['emajgroupnotidle']} {$this->lang['emajcantresetgroup']}");
			}else{
				$this->detail_group('',"{$this->lang['emajgroupnotidle']} {$this->lang['emajcantresetgroup']}");
			}
			return;
		}
		// OK
		$status = $this->emajdb->resetGroup($_POST['group']);
		if ($status > 0)
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajresetgroupok'],$_POST['group']));
			}else{
				$this->detail_group(sprintf($this->lang['emajresetgroupok'],$_POST['group']));
			}
		else
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajresetgrouperr'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajresetgrouperr'],$_POST['group']));
			}
	}

	/**
	 * Prepare set mark group: ask for the mark name and confirmation
	 */
	function set_mark_group($msg = '', $errMsg = '') {
		global $misc, $lang;

		if (!isset($_POST['mark'])) $_POST['mark'] = '';

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajsetamark']);
		$this->printMsg($msg,$errMsg);

		echo "<p>", sprintf($this->lang['emajconfirmsetmarkgroup'], $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left required\">{$this->lang['emajmark']}</th>\n";
		echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"",
			htmlspecialchars($_POST['mark']), "\" id=\"mark\"/></td></tr>\n";
		echo "</table>\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"set_mark_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" value=\"{$lang['strok']}\" id=\"ok\" disabled=\"disabled\"/>\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		echo "  $(document).ready(function () {\n";
		echo "    $(\"#mark\").keyup(function (data) {\n";
		echo "      if ($(this).val() != \"\") {\n";
		echo "        $(\"#ok\").removeAttr(\"disabled\");\n";
		echo "      } else {\n";
		echo "        $(\"#ok\").attr(\"disabled\", \"disabled\");\n";
		echo "      }\n";
		echo "    });\n";
		echo "  });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform set mark group
	 */
	function set_mark_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}
		// Check the group is always in LOGGING state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'LOGGING') {
			if ($_POST['back']=='list') {
				$this->list_group('',"{$this->lang['emajgroupnotlogging']} {$this->lang['emajcantsetmark']}");
			}else{
				$this->detail_group('',"{$this->lang['emajgroupnotlogging']} {$this->lang['emajcantsetmark']}");
			}
			return;
		}
		// Check the supplied mark group is valid
		if (!$this->emajdb->isNewMarkValidGroup($_POST['group'],$_POST['mark'])) {
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			}
			return;
		}
		// OK
		$status = $this->emajdb->setMarkGroup($_POST['group'],$_POST['mark']);
		if ($status == 0)
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajsetmarkgroupok'],$_POST['mark'],$_POST['group']));
			}else{
				$this->detail_group(sprintf($this->lang['emajsetmarkgroupok'],$_POST['mark'],$_POST['group']));
			}
		else
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajsetmarkgrouperr'],$_POST['mark'],$_POST['group']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajsetmarkgrouperr'],$_POST['mark'],$_POST['group']));
			}
	}

	/**
	 * Prepare set mark groups: ask for the mark name and confirmation
	 */
	function set_mark_groups($msg = '', $errMsg = '') {
		global $misc, $lang;

		if (!isset($_REQUEST['ma'])) {
			$this->list_groups('',$this->lang['emajnoselectedgroup']);
			return;
		}
		if (!isset($_POST['mark'])) $_POST['mark'] = '';

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajsetamark']);
		$this->printMsg($msg,$errMsg);

		// build the groups list
		$groupsList='';
		foreach($_REQUEST['ma'] as $v) {
			$a = unserialize(htmlspecialchars_decode($v, ENT_QUOTES));
			$groupsList.=$a['group'].', ';
		}
		$groupsList=substr($groupsList,0,strlen($groupsList)-2);
		echo "<p>", sprintf($this->lang['emajconfirmsetmarkgroup'], $misc->printVal($groupsList)), "</p>\n";
		// send form
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left required\">{$this->lang['emajmark']}</th>\n";
		echo "<td class=\"data1\"><input name=\"mark\" size=\"32\" value=\"",
			htmlspecialchars($_POST['mark']), "\" id=\"mark\"/></td></tr>\n";
		echo "</table>\n";
		echo "<input type=\"hidden\" name=\"groups\" value=\"", htmlspecialchars($groupsList), "\" />\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"set_mark_groups_ok\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" value=\"{$lang['strok']}\" id=\"ok\" disabled=\"disabled\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		echo "  $(document).ready(function () {\n";
		echo "    $(\"#mark\").keyup(function (data) {\n";
		echo "      if ($(this).val() != \"\") {\n";
		echo "        $(\"#ok\").removeAttr(\"disabled\");\n";
		echo "      } else {\n";
		echo "        $(\"#ok\").attr(\"disabled\", \"disabled\");\n";
		echo "      }\n";
		echo "    });\n";
		echo "  });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform set mark groups
	 */
	function set_mark_groups_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->list_groups(); exit(); }

		// Check the groups are always in LOGGING state
		$groups=explode(', ',$_POST['groups']);
		foreach($groups as $g) {
			if ($this->emajdb->getGroup($g)->fields['group_state'] != 'LOGGING') {
				listGroups(sprintf($this->lang['emajcantsetmarkgroups'],$_POST['groups'],$g));
				return;
			}
		}
		// Check the supplied mark group is valid
		if (!$this->emajdb->isNewMarkValidGroups($_POST['groups'],$_POST['mark'])) {
			$this->list_groups('',sprintf($this->lang['emajinvalidmark'],$_POST['mark']));
			return;
		}
		// OK
		$status = $this->emajdb->setMarkGroups($_POST['groups'],$_POST['mark']);
		if ($status == 0)
			$this->list_groups(sprintf($this->lang['emajsetmarkgroupok'],$_POST['mark'],$_POST['groups']));
		else
			$this->list_groups('',sprintf($this->lang['emajsetmarkgrouperr'],$_POST['mark'],$_POST['groups']));
	}

	/**
	 * Prepare comment mark group: ask for comment and confirmation
	 */
	function comment_mark_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajcommentamark']);

		$mark = $this->emajdb->getMark($_REQUEST['group'],$_REQUEST['mark']);

		echo "<p>", sprintf($this->lang['emajcommentmark'], $misc->printVal($_REQUEST['mark']), $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left\">{$lang['strcomment']}</th>\n";
		echo "<td class=\"data1\"><input name=\"comment\" size=\"100\" value=\"",
			htmlspecialchars($mark->fields['mark_comment']), "\" /></td></tr>\n";
		echo "</table>\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"comment_mark_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"mark\" value=\"", htmlspecialchars($_REQUEST['mark']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"commentmarkgroup\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform comment mark group
	 */
	function comment_mark_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->detail_group(); exit(); }

		$status = $this->emajdb->setCommentMarkGroup($_POST['group'],$_POST['mark'],$_POST['comment']);
		if ($status >= 0)
			$this->detail_group(sprintf($this->lang['emajcommentmarkok'],$_POST['mark'],$_POST['group']));
		else
			$this->detail_group('',sprintf($this->lang['emajcommentmarkerr'],$_POST['mark'],$_POST['group']));
	}

	/**
	 * Prepare rollback group: ask for confirmation
	 */
	function rollback_group() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajrlbkagroup']);

		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"rollback_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		if (isset($_REQUEST['mark'])) {
		// the mark name is already defined (coming from detail group page)
			echo "<p>", sprintf($this->lang['emajconfirmrlbkgroup'], $misc->printVal($_REQUEST['group']), $misc->printVal($_REQUEST['mark'])), "</p>\n";
			echo "<input type=\"hidden\" name=\"mark\" value=\"", htmlspecialchars($_REQUEST['mark']), "\" />\n";
		}else{
		// the mark name is not yet defined (coming from list groups page)
			$marks=$this->emajdb->getRollbackMarkGroup($_REQUEST['group']);
			echo sprintf($this->lang['emajselectmarkgroup'], $misc->printVal($_REQUEST['group']));
			echo "<select name=\"mark\">\n";
			foreach($marks as $m)
				echo "<option value=\"{$m['mark_name']}\">{$m['mark_name']} ({$m['mark_datetime']})</option>\n";
			echo "</select></p><p>\n";
		}
		echo $misc->form;
		echo "{$this->lang['emajrollbacktype']} : ";
		echo "<input type=\"radio\" name=\"rollbacktype\" value=\"unlogged\" checked>{$this->lang['emajunlogged']}";
		echo "<input type=\"radio\" name=\"rollbacktype\" value=\"logged\">{$this->lang['emajlogged']}\n";
		echo "</p><p>";
		echo "<input type=\"submit\" name=\"rollbackgroup\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform rollback_group
	 */
	function rollback_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) {
			if ($_POST['back'] == 'list') {
				$this->list_groups();
			}else{
				$this->detail_group();
			}
			exit();
		}
		// Check the group is always in LOGGING state
		$group = $this->emajdb->getGroup($_REQUEST['group']);
		if ($group->fields['group_state'] != 'LOGGING'){
			if ($_POST['back']=='list') {
				$this->list_group('',"{$this->lang['emajgroupnotlogging']} {$this->lang['emajcantrlbkgroup']}");
			}else{
				$this->detail_group('',"{$this->lang['emajgroupnotlogging']} {$this->lang['emajcantrlbkgroup']}");
			}
			return;
		}
		// Check the mark is always valid
		if (!$this->emajdb->isRollbackMarkValidGroup($_POST['group'],$_POST['mark'])){
			if ($_POST['back']=='list') {
				$this->list_group('',sprintf($this->lang['emajinvalidrlbkmark'],$_POST['mark'])." {$this->lang['emajcantrlbkgroup']}");
			}else{
				$this->detail_group('',sprintf($this->lang['emajinvalidrlbkmark'],$_POST['mark'])." {$this->lang['emajcantrlbkgroup']}");
			}
			return;
		}
		// OK
		if (isset($_POST['rollbacktype'])){				// version >= 0.10.0
			$status = $this->emajdb->rollbackGroup($_POST['group'],$_POST['mark'],$_POST['rollbacktype']=='logged');
		}else{
			$status = $this->emajdb->rollbackGroup($_POST['group'],$_POST['mark'],false);
		}
		if ($status >= 0){
			if ($_POST['back']=='list') {
				$this->list_groups(sprintf($this->lang['emajrlbkgroupok'],$_POST['group'],$_POST['mark']));
			}else{
				$this->detail_group(sprintf($this->lang['emajrlbkgroupok'],$_POST['group'],$_POST['mark']));
			}
		}else{
			if ($_POST['back']=='list') {
				$this->list_groups('',sprintf($this->lang['emajrlbkgrouperr'],$_POST['group'],$_POST['mark']));
			}else{
				$this->detail_group('',sprintf($this->lang['emajrlbkgrouperr'],$_POST['group'],$_POST['mark']));
			}
		}
	}

	/**
	 * Prepare rollback groups: ask for confirmation
	 */
	function rollback_groups() {
		global $misc, $lang;

		if (!isset($_REQUEST['ma'])) {
		// function called but no selected group
			$this->list_groups('',$this->lang['emajnoselectedgroup']);
			return;
		}
		// build the groups list
		$groupsList='';
		foreach($_REQUEST['ma'] as $v) {
			$a = unserialize(htmlspecialchars_decode($v, ENT_QUOTES));
			$groupsList.=$a['group'].', ';
		}
		$groupsList=substr($groupsList,0,strlen($groupsList)-2);

		$server_info = $misc->getServerInfo();

		if ($server_info["pgVersion"]>=8.4){
		// look for marks common to all selected groups
			$marks=$this->emajdb->getRollbackMarkGroups($groupsList);
		// if no mark is usable for all selected groups, stop
			if ($marks->recordCount()==0) {
				$this->list_groups('',sprintf($this->lang['emajnomarkgroups'],$groupsList));
				return;
			}
		}
		$this->printPageHeader();

		$misc->printTitle($this->lang['emajrlbkgroups']);

		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"rollback_groups_ok\" />\n";
		echo "<input type=\"hidden\" name=\"groups\" value=\"", htmlspecialchars($groupsList), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo sprintf($this->lang['emajselectmarkgroups'], $misc->printVal($groupsList));

		if ($server_info["pgVersion"]>=8.4){
		// pg 8.4+ => use a combo box with the only acceptable marks
			echo "<select name=\"mark\">\n";
			foreach($marks as $m)
				echo "<option value=\"",htmlspecialchars($m['mark_name']),"\">",htmlspecialchars($m['mark_name'])," (",htmlspecialchars($m['mark_datetime']),")</option>\n";
			echo "</select></p><p>\n";
		}else{
		// pg 8.3- => just use a simple text input (the mark validity check will be done in doRollbackGroups() function)
			echo "<input name=\"mark\" size=\"32\" value=\"\" /></p><p>\n";
		}
		echo $misc->form;
		echo "{$this->lang['emajrollbacktype']} : ";
		echo "<input type=\"radio\" name=\"rollbacktype\" value=\"unlogged\" checked>{$this->lang['emajunlogged']}";
		echo "<input type=\"radio\" name=\"rollbacktype\" value=\"logged\">{$this->lang['emajlogged']}\n";
		echo "</p><p>";
		echo "<input type=\"submit\" name=\"rollbackgroups\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform rollback_groups
	 */
	function rollback_groups_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->list_groups(); exit(); }

		// Check the groups are always in LOGGING state
		$groups=explode(', ',$_POST['groups']);
		foreach($groups as $g) {
			if ($this->emajdb->getGroup($g)->fields['group_state'] != 'LOGGING') {
				$this->list_groups('',sprintf($this->lang['emajcantrlbkgroups'],$_POST['groups'],$g));
				return;
			}
		}
		// Check the mark is always valid
		if (!$this->emajdb->isRollbackMarkValidGroups($_POST['groups'],$_POST['mark'])){
			$this->list_groups('',sprintf($this->lang['emajinvalidrlbkmark'],$_POST['mark']));
			return;
		}
		// OK
		if (isset($_POST['rollbacktype'])){				// version >= 0.10.0
			$status = $this->emajdb->rollbackGroups($_POST['groups'],$_POST['mark'],$_POST['rollbacktype']=='logged');
		}else{
			$status = $this->emajdb->rollbackGroups($_POST['groups'],$_POST['mark'],false);
		}
		if ($status >= 0){
			$this->list_groups(sprintf($this->lang['emajrlbkgroupsok'],$_POST['groups'],$_POST['mark']));
		}else{
			$this->list_groups('',sprintf($this->lang['emajrlbkgroupserr'],$_POST['groups'],$_POST['mark']));
		}
	}

	/**
	 * Prepare rename_mark_group: ask for the new name for the mark to rename and confirmation
	 */
	function rename_mark_group($msg = '', $errMsg = '') {
		global $misc, $lang;

		if (!isset($_POST['group'])) $_POST['group'] = '';
		if (!isset($_POST['mark'])) $_POST['mark'] = '';

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajrenameamark']);
		$this->printMsg($msg,$errMsg);

		echo "<p>", sprintf($this->lang['emajconfirmrenamemark'], $misc->printVal($_REQUEST['mark']), $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<table>\n";
		echo "<tr><th class=\"data left required\">{$this->lang['emajnewnamemark']}</th>\n";
		echo "<td class=\"data1\"><input name=\"newmark\" size=\"32\" value=\"",
			htmlspecialchars($_POST['mark']), "\" id=\"newmark\"/></td></tr>\n";
		echo "</table>\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"mark\" value=\"", htmlspecialchars($_REQUEST['mark']), "\" />\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"rename_mark_group_ok\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" value=\"{$lang['strok']}\" id=\"ok\" disabled=\"disabled\"/>\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		echo "<script type=\"text/javascript\">\n";
		echo "  $(document).ready(function () {\n";
		echo "    $(\"#newmark\").keyup(function (data) {\n";
		echo "      if ($(this).val() != \"\") {\n";
		echo "        $(\"#ok\").removeAttr(\"disabled\");\n";
		echo "      } else {\n";
		echo "        $(\"#ok\").attr(\"disabled\", \"disabled\");\n";
		echo "      }\n";
		echo "    });\n";
		echo "  });\n";
		echo "</script>";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform rename_mark_group
	 */
	function rename_mark_group_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->detail_group(); exit(); }

		// Check the supplied mark group is valid
		if (!$this->emajdb->isNewMarkValidGroup($_POST['group'],$_POST['newmark']))
			$this->detail_group('',sprintf($this->lang['emajinvalidmark'],$_POST['newmark']));
		else {
		// OK
			$status = $this->emajdb->renameMarkGroup($_POST['group'],$_POST['mark'],$_POST['newmark']);
			if ($status >= 0)
				$this->detail_group(sprintf($this->lang['emajrenamemarkok'],$_POST['mark'],$_POST['group'],$_POST['newmark']));
			else
				$this->detail_group('',sprintf($this->lang['emajrenamemarkerr'],$_POST['mark'],$_POST['group'],$_POST['newmark']));
		}
	}

	/**
	 * Prepare delete mark group: ask for confirmation
	 */
	function delete_mark() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajdelamark']);

		echo "<p>", sprintf($this->lang['emajconfirmdelmark'], $misc->printVal($_REQUEST['mark']), $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"delete_mark_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"mark\" value=\"", htmlspecialchars($_REQUEST['mark']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"deletemark\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform delete mark group
	 */
	function delete_mark_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->detail_group(); exit(); }

		$status = $this->emajdb->deleteMarkGroup($_POST['group'],$_POST['mark']);
		if ($status >= 0)
			$this->detail_group(sprintf($this->lang['emajdelmarkok'],$_POST['mark'],$_POST['group']));
		else
			$this->detail_group('',sprintf($this->lang['emajdelmarkerr'],$_POST['mark'],$_POST['group']));
	}

	/**
	 * Prepare delete before mark group: ask for confirmation
	 */
	function delete_before_mark() {
		global $misc, $lang;

		$this->printPageHeader();

		$misc->printTitle($this->lang['emajdelmarks']);

		echo "<p>", sprintf($this->lang['emajconfirmdelmarks'], $misc->printVal($_REQUEST['mark']), $misc->printVal($_REQUEST['group'])), "</p>\n";
		echo "<form action=\"plugin.php?plugin={$this->name}&amp;\" method=\"post\">\n";
		echo "<p><input type=\"hidden\" name=\"action\" value=\"delete_before_mark_ok\" />\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"", htmlspecialchars($_REQUEST['group']), "\" />\n";
		echo "<input type=\"hidden\" name=\"mark\" value=\"", htmlspecialchars($_REQUEST['mark']), "\" />\n";
		echo "<input type=\"hidden\" name=\"back\" value=\"", htmlspecialchars($_REQUEST['back']), "\" />\n";
		echo $misc->form;
		echo "<input type=\"submit\" name=\"deletebeforemark\" value=\"{$lang['strok']}\" />\n";
		echo "<input type=\"submit\" name=\"cancel\" value=\"{$lang['strcancel']}\" /></p>\n";
		echo "</form>\n";

		$this->printEmajFooter();
		$misc->printFooter();
	}

	/**
	 * Perform delete before mark group
	 */
	function delete_before_mark_ok() {
		global $lang;

		// process the click on the <cancel> button
		if (isset($_POST['cancel'])) { $this->detail_group(); exit(); }

		$status = $this->emajdb->deleteBeforeMarkGroup($_POST['group'],$_POST['mark']);
		if ($status > 0)
			$this->detail_group(sprintf($this->lang['emajdelmarksok'],$status,$_POST['mark'],$_POST['group']));
		else
			$this->detail_group('',sprintf($this->lang['emajdelmarkserr'],$_POST['mark'],$_POST['group']));
	}

	/**
	 * Call the sqleditor.php page passing the sqlquery to display in $_SESSION
	 * We are already in the target frame
	 */
	function call_sqledit() {
		global $misc;

		$_SESSION['sqlquery'] = $_REQUEST['sqlquery'];
		echo "<meta http-equiv=\"refresh\" content=\"0;url=sqledit.php?subject=table&amp;{$misc->href}&amp;action=sql&amp;paginate=true\">";
	}

	/**
	 * Generate the page header including the trail and the tabs
	 */
	function printPageHeader($tabs ='emaj',$tab = 'emajgroups') {
		global $misc;

		$misc->printHeader($this->lang['emajplugin']);
		$misc->printBody();
		$misc->printTrail('database');
//		$misc->printTabs('database','emaj');
		$misc->printTabs($tabs,$tab);
		return ;
	}

	/**
	 * Display the emaj header line including the version number
	 */
	function printEmajHeader($urlvar,$title) {
		global $lang, $misc;
	// $urlvar is the piece of the url containing the variables needed to refresh the page

	// If Emaj is not usable for this database, only display a message
		if (!(isset($this->emajdb)&&$this->emajdb->isEnabled()&&$this->emajdb->isAccessible())) {
			echo "<div class=\"topbar\"><table style=\"width: 100%\"><tr><td><span class=\"platform\">{$this->lang['emajnotavail']}</span></td></tr></table></div>";
			return 0;
		}
	// If Emaj version is too old, only display a message
		if ($this->emajdb->getNumEmajVersion() < $this->oldest_supported_emaj_version_num) {
			echo "<div class=\"topbar\"><table style=\"width: 100%\"><tr><td><span class=\"platform\">";
			echo sprintf($this->lang['emajtooold'],$this->emajdb->getEmajVersion(),$this->oldest_supported_emaj_version);
			echo "</span></td></tr></table></div>";
			return 0;
		}

/*	// generate the E-Maj tabs
		echo "<table class=\"tabs\" style=\"margin-top:10px; margin-bottom:10px;\"><tr>\n";

		// List groups
		echo "<td style=\"width:25%\" class=\"tab\">\n";
		echo "<a href=\"plugin.php?plugin={$this->name}&amp;action=list_groups&amp;{$misc->href}\">\n";
		echo "<span class=\"icon\">\n";
		echo "<img src=\"{$misc->icon(array($this->name,'EmajGroup'))}\" alt=\"Groups\" />\n";
		echo "</span><span class=\"label\">{$this->lang['emajgroups']}</span></a></td>\n";

		// Define groups
		if ($this->emajdb->isEmaj_Adm()){
			echo "<td style=\"width:25%\" class=\"tab\">\n";
			echo "<a href=\"plugin.php?plugin={$this->name}&amp;action=define_groups&amp;{$misc->href}\">\n";
			echo "<span class=\"icon\">\n";
			echo "<img src=\"{$misc->icon('Subscriptions')}\" alt=\"Define groups\" />\n";
			echo "</span><span class=\"label\">{$this->lang['emajdefinegroups']}</span></a></td>\n";
		}

		// Monitor the rollback activity
		if ($this->emajdb->getNumEmajVersion() >= 10100){			// version >= 1.1.0
			echo "<td style=\"width:25%\" class=\"tab\">\n";
			echo "<a href=\"plugin.php?plugin={$this->name}&amp;action=rlbk_activity&amp;{$misc->href}\">\n";
			echo "<span class=\"icon\">\n";
			echo "<img src=\"{$misc->icon(array($this->name,'EmajRollback'))}\" alt=\"Monitor rollback activity\" />\n";
			echo "</span><span class=\"label\">{$this->lang['emajmonitorrlbk']}</span></a></td>\n";
		}

		// Check E-Maj environment
		echo "<td style=\"width:25%\" class=\"tab\">\n";
		echo "<a href=\"plugin.php?plugin={$this->name}&amp;action=check&amp;{$misc->href}\">\n";
		echo "<span class=\"icon\">\n";
		echo "<img src=\"{$misc->icon('CheckConstraint')}\" alt=\"E-Maj envir.checks\" />\n";
		echo "</span><span class=\"label\">{$this->lang['emajcheck']}</span></a></td>\n";
		echo "</tr></table>\n";
*/

	// generate the E-Maj header
		$currTime = date('H:i:s');
		echo "<div class=\"topbar\"><table style=\"width: 100%\"><tr>\n";
		echo "<td style=\"width:15px\"><a href=\"plugin.php?plugin={$this->name}&amp;{$urlvar}&amp;{$misc->href}\"><img src=\"{$misc->icon('Refresh')}\" alt=\"{$lang['strrefresh']}\" title=\"{$lang['strrefresh']}\" /></a></td>\n";
		echo "<td><span class=\"platform\">{$currTime}&nbsp;&nbsp;";
		echo "<a href=\"plugin.php?plugin={$this->name}&amp;action=check&amp;back=list&amp;{$misc->href}\" title=\"{$this->lang['emajcheck']}\">";
		echo "E-Maj {$this->emajdb->getEmajVersion()}</a></span>";
		echo "&nbsp;&nbsp;[ {$this->emajdb->getEmajSize()} ]";
		echo "&nbsp;&nbsp;<span class=\"platform\">-&nbsp;&nbsp;{$title}</span></td>\n";
		echo "<td style=\"width:15px\"><a href=\"#bottom\"><img src=\"{$misc->icon(array($this->name,'Bottom'))}\" alt=\"{$this->lang['emajpagebottom']}\" title=\"{$this->lang['emajpagebottom']}\" /></a></td>\n";
		echo "</tr></table></div>\n";

		return 1;
	}

	/**
	 * Display the emaj header line including the version number
	 */
	function printEmajFooter() {

	// generate the E-Maj footer
		$currTime = date('H:i:s');
		echo "<div class=\"footer\"><a name=\"bottom\"></a></div>\n";

		return;
	}

	/**
	 * Print out a standart message and/or and error message
	 * @param $msg			The message to print
	 *        $errorFlag	Optional flag indicating whether the message is an error message
	 */
	function printMsg($msg,$errMsg) {
		if ($msg != '') echo "<p class=\"message\">{$msg}</p>\n";
		if ($errMsg != '') echo "<p style=\"color:red\">{$errMsg}</p>\n";
	}

	function tree() {
		global $misc;

		$reqvars = $misc->getRequestVars('emaj');

		$groups = $this->emajdb->getGroups();

		$attrs = array(
			'text' => field('group_name'),
			'icon' => $this->icon('EmajGroup'),
			'iconaction' => url	('plugin.php',$reqvars,
				array	(
					'action'  => 'detail_group',
					'plugin' => $this->name,
					'group'  => field('group_name')
					)
				),
			'toolTip' => field('group_comment'),
			'action' => url	('plugin.php',$reqvars,
				array	(
					'action'  => 'detail_group',
					'plugin' => $this->name,
					'group'  => field('group_name')
					)
				),
		);

		$misc->printTree($groups, $attrs,'emajgroups');
		exit;
	}
}
?>
